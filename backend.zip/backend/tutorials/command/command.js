// commands.js
class AddCommand {
  constructor(valueToAdd) {
    this.valueToAdd = valueToAdd;
  }

  execute(currentValue) {
    return currentValue + this.valueToAdd;
  }

  undo(currentValue) {
    return currentValue - this.valueToAdd;
  }
}

class SubstractCommand {
  constructor(valueToSubtract) {
    this.valueToSubtract = valueToSubtract;
  }

  execute(currentValue) {
    return currentValue - this.valueToSubtract;
  }

  undo(currentValue) {
    return currentValue + this.valueToSubtract;
  }
}

module.exports = {
  AddCommand: AddCommand,
  SubtractCommand: SubstractCommand,
};

//ARRAY:
//let arr =[]
//arr.push(1) -1
//arr.push(2) -2
//arr.pop() -2
