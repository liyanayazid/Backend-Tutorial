// // index.js
// const House = require("./house");

// const myHouse = new House("John Street 14", 4, true, true);
// console.log(myHouse.showInfo());

//NEW FORMAT
const HouseBuilder = require('./house_builder');

const houseWithParking =
    new HouseBuilder('Street 1').setFloor(2).setParking(true).setGarden(false).buildInfo();

houseWithParking.showInfo();

const houseWithGarden =
    new HouseBuilder('Street 2').setFloor(3).setParking(false).setGarden(true).buildInfo();

houseWithGarden.showInfo();
