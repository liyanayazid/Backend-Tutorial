// freshner.js
class Freshner {
  spray() {
    console.log("A nice smell spreads through the air");
  }
}

module.exports = Freshner;
