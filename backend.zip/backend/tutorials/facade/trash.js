// trash.js
class Trash {
  takeOutTrash() {
    console.log("The trash is taken out");
  }
}

module.exports = Trash;
