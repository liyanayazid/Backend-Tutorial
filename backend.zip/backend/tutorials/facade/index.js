// // index.js
// const Bed = require("./bed");
// const Freshner = require("./freshner");
// const Trash = require("./trash");

// function cleanHouse() {
//   new Bed().makeTheBed();
//   new Freshner().spray();
//   new Trash().takeOutTrash();
// }

// cleanHouse();

// SIMPLER WAY
const HouseCleaningFacade = require('./house_cleaning_facade');

(new HouseCleaningFacade()).cleanTheHouse();
