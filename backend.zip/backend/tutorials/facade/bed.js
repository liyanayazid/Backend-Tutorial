// bed.js
class Bed {
  makeTheBed() {
    console.log("The bed is ready");
  }
}

module.exports = Bed;
