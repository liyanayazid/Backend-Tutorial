// advance_shipping.js
class AdvanceShipping {
  login(credentials) {
    /* ... */
  }
  setStart(start) {
    /* ... */
  }
  setDestination(destination) {
    /* ... */
  }
  calculate(weight) {
    return "$39.50";
  }
}

module.exports = AdvanceShipping;
