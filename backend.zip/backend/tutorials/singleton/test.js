const Bank = require("./bank");

const fund = new Bank(); // a separate instance
const atm = new Bank(); // a separate instance

fund.deposit(10000);
atm.deposit(20);

console.log(`total-atm: ${atm.total()}`);
fund.deposit(2000);
console.log(`total-fund after depositing 2000: ${fund.total()}`);
