# Installation guide

## Basic

```shell
sudo apt-get clean
sudo apt update
sudo apt upgrade
```
## Timezone

List current timezone

```
$ timedatectl

Local time: Mon 2021-11-08 04:33:21 UTC
Universal time: Mon 2021-11-08 04:33:21 UTC
RTC time: Mon 2021-11-08 04:33:21    
Time zone: UTC (UTC, +0000)
```

List available timezones

```
timedatectl list-timezones
```

Update the timezone to UTC

```
sudo timedatectl set-timezone UTC
```

## Locale

Check current locale

```
$ locale

LANG=en_US.UTF-8
LANGUAGE=
LC_CTYPE="en_US.UTF-8"
LC_NUMERIC=en_US.UTF-8
LC_TIME=en_US.UTF-8
LC_COLLATE="en_US.UTF-8"
LC_MONETARY=en_US.UTF-8
LC_MESSAGES="en_US.UTF-8"
LC_PAPER=en_US.UTF-8
LC_NAME=en_US.UTF-8
LC_ADDRESS=en_US.UTF-8
LC_TELEPHONE=en_US.UTF-8
LC_MEASUREMENT=en_US.UTF-8
LC_IDENTIFICATION=en_US.UTF-8
LC_ALL=
```

Configure current locale

```
sudo dpkg-reconfigure locales
```

Select en_US.UTF-8

## Git
Confirm if already installed. If not, proceed with next steps
```shell
git --version
sudo apt install git
```

## Wireshark

```sh
sudo add-apt-repository ppa:wireshark-dev/stable
sudo apt update
sudo apt install wireshark
```

Even if you have an older version of Wireshark installed, it will be updated to the newer version.

While installing, you will be asked whether to allow non-superusers to capture packets. Select Yes to allow and No to restrict non-superusers to capture packets & finish the installation.

You may have to restart your computer to complete the installation.

You can now launch wireshark from the search bar GUI.

## Node.js and TypeScript

Refer http://github.com/nodesource/distributions/blob/master/README.md#deb for the latest instructions.

Below steps are explained for Node.js version 14 with npm and typescript

Remove any existing installation
```shell
sudo apt-get remove nodejs
```

Proceed with installing latest LTS version
```shell
curl -fsSL https://deb.nodesource.com/setup_14.x | sudo -E bash -
sudo apt-get install -y nodejs
sudo apt install npm
sudo npm install -g npm@7.21.1
sudo npm i typescript@^4.4.4 -g
```

**Optional**: install build tools

To compile and install native add ons from `npm` you may also need to install build tools:

```shell
sudo apt-get install -y build-essential
```

## Postgres

As `root` user:

```bash
apt install curl ca-certificates gnupg
curl https://www.postgresql.org/media/keys/ACCC4CF8.asc |
    gpg --dearmor > /etc/apt/trusted.gpg.d/apt.postgresql.org.gpg
echo "deb http://apt.postgresql.org/pub/repos/apt/ lsb_release -cs-pgdg main" |sudo tee  /etc/apt/sources.list.d/pgdg.list
apt-get update
apt install postgresql-common 
apt install postgresql-client-13
install -g postgres -o postgres -d /etc/postgresql-common/createcluster.d
echo 'create_main_cluster = false' >/etc/postgresql-common/createcluster.d/create_main_cluster.conf
chown postgres:postgres /etc/postgresql-common/createcluster.d/create_main_cluster.conf
apt install postgresql-13
```

## Docker

Official documentation: https://docs.docker.com/engine/install/ubuntu/

Remove previous installation

```
sudo apt-get remove docker docker-ce docker-ce-cli containerd.io docker-engine docker.io containerd runc
```

Install

```
sudo apt-get update
sudo apt-get install \
    ca-certificates \
    curl \
    gnupg \
    lsb-release
    
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg

echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu \
  $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
  
sudo apt-get update
sudo apt-get install docker-ce docker-ce-cli containerd.io
```

Verify installation

```
docker run hello-world
```

### docker-compose

```
sudo curl -L "https://github.com/docker/compose/releases/download/1.29.2/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose
sudo ln -s /usr/local/bin/docker-compose /usr/bin/docker-compose

# verify the installation
docker-compose --version
```
