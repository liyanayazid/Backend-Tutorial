# backend 
Design Pattern: Builder
Builder allow constructing objects step by step. Unlike other patterns, Builder doesn't require products to have a common interface. That makes it possible to produce different products using the same construction process.

2nd Design Pattern: Facade
Facade pattern hides the complexities of the system and provides an interface to the client using which the client can access the system.
