DROP SCHEMA IF EXISTS deriv CASCADE;

CREATE SCHEMA deriv;

CREATE TABLE deriv.person (
    id BIGSERIAL PRIMARY KEY,
    firstname TEXT NOT NULL,
    lastname TEXT NOT NULL,
    homeaddress TEXT NOT NULL
);