// //entry point

const Pool = require("pg").Pool;
const pool = new Pool({
  user: "me",
  host: "localhost",
  database: "api",
  password: "password",
  port: 5432,
});
const getPerson = (request, response) => {
  pool.query("SELECT * FROM person ORDER BY id ASC", (error, results) => {
    if (error) {
      throw error;
    }
    response.status(200).json(results.rows);
  });
};

const getPersonById = (request, response) => {
  const id = parseInt(request.params.id);

  pool.query("SELECT * FROM person WHERE id = $1", [id], (error, results) => {
    if (error) {
      throw error;
    }
    response.status(200).json(results.rows);
  });
};

const createPerson = (request, response) => {
  const data = request.body;
  console.log("Firstname: " + data.firstname);
  console.log("Lastname: " + data.lastname);
  console.log("Address: " + data.homeaddress);

  pool.query(
    "INSERT INTO person (firstname, lastname, homeaddress) VALUES ($1, $2, $3)",
    [data.firstname, data.lastname, data.homeaddress],
    (error, results) => {
      if (error) {
        throw error;
      }
      response.status(201).send(`Person added with ID: ${result.insertId}`);
    }
  );
};

const updatePerson = (request, response) => {
  const id = parseInt(request.params.id);
  const { firstname, lastname, homeaddress } = request.body;

  pool.query(
    "UPDATE person SET firstname = $1, lastname = $2, address = $3 WHERE id = $4",
    [firstname, lastname, homeaddress],
    (error, results) => {
      if (error) {
        throw error;
      }
      response.status(200).send(`Person modified with ID: ${id}`);
    }
  );
};

const deletePerson = (request, response) => {
  const id = parseInt(request.params.id);

  pool.query("DELETE FROM person WHERE id = $1", [id], (error, results) => {
    if (error) {
      throw error;
    }
    response.status(200).send(`Person deleted with ID: ${id}`);
  });
};

module.exports = {
  getPerson,
  getPersonById,
  createPerson,
  updatePerson,
  deletePerson,
};
