//Here is our complete index.js, the entry point of the API server.
const express = require("express");
const bodyParser = require("body-parser");
const app = express();
const db = require("./server");
const port = 3000;

app.use(bodyParser.json());
app.use(
  bodyParser.urlencoded({
    extended: true,
  })
);

app.get("/", (request, response) => {
  response.json({
    Person: "firstname: nur, lastname: liyana, address: cyberjaya",
  });
});

app.get("/person", db.getPerson);
app.get("/person/:id", db.getPersonById);
app.post("/person", db.createPerson);
app.put("/person/:id", db.updatePerson);
app.delete("/person/:id", db.deletePerson);

app.listen(port, () => {
  console.log(`App running on port ${port}.`);
});
