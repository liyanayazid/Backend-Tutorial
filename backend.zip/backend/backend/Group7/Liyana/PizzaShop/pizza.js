
// class Pizza {
//   constructor(builder) {
//     this.size = builder.size;
//     this.topping = builder.topping;
//     this.extracheese = builder.extracheese;
 
//   }

//   showInfo() {
//     console.log(this);
//   }
// }

// module.exports = Pizza;

//FACADE
class Pizza {
  PeperoniPizza() {
    console.log("--Peperoni pizza--");
  }

  BananaPizza() {
    console.log("--Banana pizza--");
  }

  ChickenIsland() {
    console.log("--Chicken Island pizza--");
  }
}


module.exports = Pizza;
