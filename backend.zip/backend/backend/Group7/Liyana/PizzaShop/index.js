// // index.js
// const PizzaBuilder = require("./pizza_builder");

// const pizza1 = new PizzaBuilder("personal")
//   .setTopping("chocolate")
//   .setExtraCheese(true)
//   .buildInfo();

// pizza1.showInfo();

// const pizza2 = new PizzaBuilder("large")
//   .setTopping("beef")
//   .setExtraCheese(false)
//   .buildInfo();

// pizza2.showInfo();

const PizzaShop = require("./pizza_builder");

new PizzaShop().CheesePizza();
