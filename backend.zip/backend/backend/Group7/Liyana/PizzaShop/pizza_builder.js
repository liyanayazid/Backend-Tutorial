// const Pizza = require("./pizza");

// class PizzaBuilder {
//   constructor(size) {
//     this.size = size;
//   }

//   setTopping(topping) {
//     this.topping = topping;
//     return this;
//   }

//   setExtraCheese(extracheese) {
//     this.extracheese = extracheese;
//     return this;
//   }

//   buildInfo() {
//     return new Pizza(this);
//   }
// }

// module.exports = PizzaBuilder;

// house_cleaning_facade.js
const Pizza = require("./pizza");
const Topping = require("./topping");
const topping = require("./topping");

class PizzaShop {
  constructor({ pizza = new Pizza(), topping = new Topping() } = {}) {
    this.pizza = pizza;
    this.topping = topping;
  }

  CheesePizza() {
    this.pizza.PeperoniPizza();
    this.topping.chili();
    this.pizza.BananaPizza();
    this.topping.extraCheese();
    this.topping.chocolate();
    this.pizza.ChickenIsland();
    this.topping.beef();
  }
}

module.exports = PizzaShop;
