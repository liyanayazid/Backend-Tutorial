class Topping {
  chili() {
    console.log("Add-on: Chili");
  }

  extraCheese() {
    console.log("Add-on: Cheese");
  }

  chocolate() {
    console.log("Add-on: Chocolate");
  }

  beef() {
    console.log("Add-on: Beef");
  }
}

module.exports = Topping;
