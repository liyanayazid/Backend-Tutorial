var WebSocketServer = require("ws").Server;
var wss = new WebSocketServer({ port: 8080 });

var sockets = [];
var messageInt;

wss.on("connection", function (ws) {
  ws.on("message", (data) => {
    let input = JSON.parse(data.toString());
    console.log(input);

    if (input.action === "start") {
      messageInt = setInterval(function () {
        var randomNum = Math.floor(
          Math.random() * (input.max - input.min) + input.min
        );
        ws.send(randomNum.toString());
        console.log("Random Number: " + randomNum);
      }, 1000 * input.interval);
    }

    if (input.action === "stop") {
      clearInterval(messageInt);
    }
  });

  sockets.push(ws);
});
