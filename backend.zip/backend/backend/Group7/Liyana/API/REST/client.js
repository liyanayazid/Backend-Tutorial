const https = require("https");
const url = "https://api.blockchain.com/v3/exchange/symbols";

const request = https.request(url, (response) => {
  let data = "";
  response.on("data", (chunk) => {
    data = data + chunk.toString();
  });

  response.on("end", () => {
    const body = JSON.parse(data);
    //get object key
    console.log(Object.keys(body));
  });
});

request.on("error", (error) => {
  console.log("ERROR", error);
});

request.end();
