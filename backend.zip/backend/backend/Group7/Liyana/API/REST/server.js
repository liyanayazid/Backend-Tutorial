const express = require("express");
var fs = require("fs");
const app = express();
app.use(express.json());

app.get("/", (req, res) => {
  res.send("Welcome New User!");
});

//GET 
app.get("/api/users", (req, res) => {
  fs.readFile(__dirname + "/" + "users.json", "utf8", function (err, data) {
    console.log(data);
    res.end(data);
  });
});

//POST 
var user = {
  User4: {
    email: "suhaila@gmail.com",
    firstName: "Nur",
    lastName: "Suhaila",
    age: 20,
    languages: ["English", "Spanish"],
  },
};

app.post("/api/users", (req, res) => {
  fs.readFile(__dirname + "/" + "users.json", "utf8", function (err, data) {
    data["User3"] = user["User3"];
    console.log(data);
    res.end(JSON.stringify(data));
    fs.writeFile("users.json", (err) => {
      if (err) {
        console.log(err);
      }
    });
  });
});

//PUT 
app.put("/api/users/:id", (req, res) => {
  fs.readFile(__dirname + "/" + "users.json", "utf8", function (err, data) {
    var users = JSON.parse(data);
    var user = users["user" + req.params.id];
    console.log(user);
    res.end(JSON.stringify(user));
  });
});

//DELETE
var id = 2;
app.delete("/api/users/:id", (req, res) => {
  fs.readFile(__dirname + "/" + "users.json", "utf8", function (err, data) {
    data = JSON.parse(data);
    delete data["user" + 2];
    console.log(data);
    res.end(JSON.stringify(data));
  });
});

const port = process.env.PORT || 8080;
app.listen(port, () => console.log(`Listening on port ${port}..`));
