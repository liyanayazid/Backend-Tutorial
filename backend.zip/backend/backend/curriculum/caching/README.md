# Caching hand-on exercise

## Preparing

You need to install few packages on your laptop before you can start working on the task.

First of all you need to install `make` command if you don't  have it.

```sh

sudo apt-get install -y make

```

also, please download all images required for this hands-on

```sh

make download

```

Now, you're prepared.

## Problem definition 

We want to develop a new library for caching which will provide the possibility to use different storage systems.

What do we have to start with?

- `./src/cache.js` - this file contains backbone for your future library, with detailed description about requirements and hints about implementation.
- `./test/*` - this directory contains test files, which you can run against your library that you can check it complies with specifications.

We want to introduce 2 abstractions in our library:

- `Cache Storage` will be responsible for storing information. It should provide operations like `set`, `get` and etc. Whole interface of this abstraction could be found in `./src/cache.js
- `Cache` will be responsible for caching logic, for example checking the existence of the `keys` in cache storage, calculating values for caching in case of cache miss and so on.

For Cache Storage abstraction we prepared skeletons, that you can use them to write you code:
    - SimpleCacheStorage - simple key/value storage, is the best class to start with. You will need to implement possibility to interact with hash map(`Object` in JS), that you can set and get values from that hash map.
    - RedisCacheStorage - this storage will provide possibility to interact with Redis server.
    - LRUCacheStorage - it's more complex in memory storage which will support LRU replacement policy.

For Cache abstraction, you can use the prepared class `Cache`. After implementing each of the `CacheStorage` abstractions, you may refer to the tests in this directory `./test/*` for more details on the expected usage implementation of your new `CacheStorage` object. Do not forget to run the tests for your code before working on the next `CacheStorage` abstraction.

Suggested ordering:

1. Implement `SimpleCacheStorage` class.
2. Implement minimal required logic for `Cache` class to be able past tests in file `01_SimpleCache.test.js`
3. Implement logic in `RedisCacheStorage` class.
4. Implement minimal required logic for `Cache` class to be able past tests in file `02_RedisCache.test.js`
5. Implement logic in `LRUCacheStorage` class.
6. Implement minimal required logic for `Cache` class to be able past tests in file `03_LRUCache.test.js`

## How to test your code

You can find prepared test files in directory `./test/`. you can use `make` to run tests for different storages.

- `make test_simple` to test SimpleCacheStorage
- `make test_redis` to run Redis tests
- `make test_lru` to test your LRU storage
- `make test_all` to test all together
