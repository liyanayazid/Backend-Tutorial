```
// There libraries may be useful for your implementation,
// but you're not limited to use only them.
import {List, Item} from 'linked-list'
import AsyncLock from 'async-lock'

/**
 * You need to implement class which will provide facilities for working with cache.
 *
 * Requirements:
 * 
 * - implementation should not be depended to any particular storage.
 *   As long as cache backend object provides compatible interface class should be able to use it. 
 *   Interface for cache backend is described in comments for SimpleCache, RedisCache and LRUCache classes
 * 
 * - It should provide possibility to retrieve values from cache by requested cache key.
 *   
 * - In case of cache miss, our library should be able new value for requested key by executing provided generator functions. 
 * 
 * - The class should provide a method for cache invalidation, which will remove value from the cache for the requested key.  
 *  
 * - We should be able to define expiration time for our cache keys. 
 *   Expired keys should be invalidated by our library when the time comes.
 * 
 * - The class should provide possibility to case as simple data like strings and numbers, 
 *   but also complex data structures like arrays and objects.
 * 
 * 
 * Advanced tasks:
 * 
 * - In case of receiving multiple concurrent requests to the same cache key, which is not stored yet, 
 *   generator function should be executed only once and all concurrent requests should retrieve same value.
 *   This feature should help to reduce load on our backend.
 * 
 * - The class should provide a feature of cache warm-up. During request we should check ttl time of the key.
 *   If key is about to expire, instead of just returning stored value, 
 *   our library should run generator function and update value in cache.
 *   Only one request should do warming up for the cache key at any given time.
 *   This feature will help us avoid blocking multiple concurrent request in cache miss case.
 *  
 */
class Cache {
    /**
     * Creates instance of Cache class.
     *
     * @param {Object} backend - Object which represents cache storage. it could be instance of LRUCache or RedisCache
     *
     */
    constructor(backend) {
        this.backend = Object(backend);
    }

    /**
     * Method returns cached value for requested cache key.
     * In case of cache miss generator function will be executed
     * for calculating value for the key. The calculated value will be saved in cache storage.
     *
     * @param {string} [key=cacheKey1] - key which should be used for reading or storing value
     * @param {Object} params - parameters of cache key
     * @param {string} [params.ttl=30] - time to live for cache key. Accept values in seconds.
     * @param {string} [params.warmUpTTL=5] - Time when cached value need to be updated. for example if key ttl is reached 5 sec, warm up need to be triggered. 
     * @param {function} generator - function for calculating value for the key, in case of cache miss.
     *
     * @example
     * let val = await myCache.cache('myKey', {}, () => { return 'Test Value' })
     *
     * @example
     * //set expiration time for cache key
     * let val = await myCache.cache('myKey', {ttl: 30}, () => { return 'Test Value' })
     * 
     * @example
     * //set expiration time for cache key and warm up time
     * let val = await myCache.cache('myKey', {ttl: 30, warmUpTTL: 5}, () => { return 'Test Value' })
     *
     * @returns {*} value for requested cache key.
     */

    async cache(key, params, generator) {

        let ttlKey = await this.backend.get(key)

        //In case of cache miss, generator function will be executed
        if(ttlKey == null){
            await this.backend.set(key, generator(), params);
            return await this.backend.get(key);
        }
        else{
            return ttlKey;
        }
        
    }

    /**
     * Method removes value for requested cache key.
     *
     * @param {string} [key=cacheKey1] key which need to be invalidated
     *
     * @example
     * await myCache.invalidate('myKey')
     */

    async invalidate(key) {
         return this.backend.del(key);
    }
}


/**
 * Cache storage which provides simple functionality for caching values in memory.
 * in this implementation we don't need to be worry about eviction policy or expiration time for cache values.
 * 
 * Requirement:
 * - The class should provide key-value storage.
 *   Hashmap data structure probably will be a good to start with.
 */
class SimpleCacheStorage {
    /**
     * Creates instance of SimpleCache class
     */
    constructor() {
        this.storage = new Object()
    }

    /**
     * The method returns value for requested key from cache storage.
     * 
     * @param {string} [key=cacheKey1] 
     * @returns {*} value for requested key. In case key is not presented in storage, null will be returned.
     */
    async get(key) {
        return this.storage[key];
    }

    /**
     * This class doesn't support TTL
     * We keep this method for the sake of having a consistent interface with other cache backends. 
     * 
     * @param {string} [key=cacheKey1] cache key which need to be checked
     * @returns {num} this method could return 2 possible values:
     *                -2 - in case item is not exist in cache storage
     *                -1 - in case item exists 
     */
    async ttl (key) {

        if(!this.storage[key]){
            //if key not exist
            return -2; 
        }
        else{
            return -1;
        }
    }

    /**
     * The method saves provided pair of key and value to cache storage
     * @param {string} [key=cacheKey1] Cache key
     * @param {*} [key=someValue] Cache value
     */
    async set(key, value) {
      return  this.storage[key] = value
        
    } 

    /**
     * The method removes key from cache storage
     * @param {string} [key=cacheKey1] Cache key
     */
    async del(key) {
       return delete this.storage[key]
    }
}

/**
 * Cache storage which provides facility to cache data in Redis.
 * 
 * Requirement:
 * - ioredis(https://www.npmjs.com/package/ioredis) library must be used as redis client in your implementation. 
 *   Unit tests depend on this library. Redis object will be passed as first argument to class constructor
 * 
 * - Class should provide possibility to set TTL for cache values in Redis.
 * 
 * - This storage should provide functionality for serializing complex data structures like Array and Object.
 * 
 * For implementation you'll need to use following redis commands:
 * - SET https://redis.io/commands/set
 * - GET https://redis.io/commands/get
 * - DEL https://redis.io/commands/del
 * - TTL https://redis.io/commands/ttl
 */


class RedisCacheStorage {
    /**
     * Creates instance of RedisCache class
     */
    constructor(redis) {
        this.redis = Object(redis)
    }

    /**
     * The method returns value for requested key from cache storage.
     * 
     * @param {string} [key=cacheKey1] 
     * @returns {*} value for requested key. In case key is not presented in storage, null will be returned.
     */
    async get(key) {

    if (await this.redis.get(key)) {
      return JSON.parse(await this.redis.get(key));
    } 
    else {
      return null;
    }

    }

    /**
     * The method returns current value of TTL for requested cache key
     * 
     * @param {string} [key=cacheKey1] cache key which need to be checked
     * @returns {num} return time left the key to be expired. value in seconds.
     *                Also this method can return 2 special values:
     *                -2 - in case item is not exist in cache storage
     *                -1 - in case item exists 
     */
    async ttl (key) {
        return await this.redis.ttl(key)
    }

    /**
     * The method saves provided pair of key and value to cache storage
     * @param {string} [key=cacheKey1] Cache key
     * @param {*} [key=someValue] Cache value
     * @param {Object} params - parameters of cache key
     * @param {string} [params.ttl=30] - time to live for cache key. Accept values in seconds.
     */
    async set(key, value, params) {
 
        if (params && Object.keys(params).length !== 0) {
            await this.redis.set(key, JSON.stringify(value), "ex", params.ttl);
         } 
         else {
         await this.redis.set(key, JSON.stringify(value));
        }
    }


    /**
     * The method removes key from cache storage
     * @param {string} [key=cacheKey1] Cache key
     */
    async del(key) {
         delete this.redis.del(key)
    }
}


/**
 * Cache storage which provides facility to cache data in application memory.
 * 
 * Requirement:
 * 
 * - As an eviction policy for storage LRU(Least recently used) need to be implemented.
 *   https://en.wikipedia.org/wiki/Cache_replacement_policies#Least_recently_used_(LRU)
 * 
 * - Class should provide possibility to set TTL for cache values.
 *   Value which reach their expiration time should be automatically removed.
 * 
 * For implementing LRU algorith you will need to use 2 data structures:
 * 
 * - HashMap(Object), which will be used to store an index of the cache,
 *   to be able access any item in cache memory for a constant time.
 * 
 * - Double Linked List or Array for organizing a queue of cache values.
 *   The queue is required here for organizing cache values in order of the last used time.
 *   Double Linked List is better option to use because
 *   it's more efficient for most of operations which required for this task.
 *   But feel free to use Array if you are more familiar with this data structure, 
 *   it also provides all essential properties.
 */
 class LRUCacheStorage {
    /**
     * Creates instance of LRUCache class
     */
    constructor(limit = 0) {
        // Your code should be here ...
    }

    /**
     * The method returns value for requested key from cache storage.
     * 
     * @param {string} [key=cacheKey1] 
     * @returns {*} value for requested key. In case key is not presented in storage, null will be returned.
     */
    async get(key) {
        // Your code should be here ...
    }

    /**
     * The method returns current value of TTL for requested cache key
     * 
     * @param {string} [key=cacheKey1] cache key which need to be checked
     * @returns {num} return time left the key to be expired. value in seconds.
     *                Also this method can return 2 special values:
     *                -2 - in case item is not exist in cache storage
     *                -1 - in case item exists 
     */
    async ttl (key) {
        // Your code should be here ...
    }

    /**
     * The method saves provided pair of key and value to cache storage
     * @param {string} [key=cacheKey1] Cache key
     * @param {*} [key=someValue] Cache value
     * @param {Object} params - parameters of cache key
     * @param {string} [params.ttl=30] - time to live for cache key. Accept values in seconds.
     */
    async set(key, value, params) {
        // Your code should be here ...
    }

    /**
     * The method removes key from cache storage
     * @param {string} [key=cacheKey1] Cache key
     */
    async del(key) {
        // Your code should be here ...
    }
}

export { Cache, SimpleCacheStorage, LRUCacheStorage, RedisCacheStorage };
```;
