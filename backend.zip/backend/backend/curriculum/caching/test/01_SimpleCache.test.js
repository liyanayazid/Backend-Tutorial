import assert  from 'assert';
import { Cache, SimpleCacheStorage }  from '../src/cache.js';

describe('Simple Cache Storage', () => {
    it('Get and Set', async () => {
        let storage = new SimpleCacheStorage()
        
        let val = await storage.get('testKey')
        assert.equal(val, null) //receive null because no value in the storage

        await storage.set('testKey','TestValue')

        val = await storage.get('testKey')
        assert.equal(val, 'TestValue')
    });

    it('Remove key', async () => {
        let storage = new SimpleCacheStorage()
        
        await storage.set('testKey','TestValue')

        await storage.del('testKey','TestValue')

        let val = await storage.get('testKey')
        assert.equal(val, null)
    });

    it('Get TTL', async () => { //already have test, need to create file to pass the test
        let storage = new SimpleCacheStorage()

        assert.equal(await storage.ttl('testKey'), -2)
        
        await storage.set('testKey','TestValue')

        assert.equal(await storage.ttl('testKey'), -1)
    });
});

describe('Simple Cache', () => {
    it('Caching', async () => {
        let cache = new Cache(new SimpleCacheStorage())

        /* In case of cache miss, cache method should execute generator function
         * and store calculated value */
        let val1 = await cache.cache('testKey1', {}, () => {return 'TestValue'})
        assert.equal(val1, 'TestValue')

        /* In case of cache hit, cache method should return stored value */
        let val2 = await cache.cache('testKey1', {}, () => {return 'AnotherTestValue'})
        assert.equal(val2, 'TestValue')
    });

    it('Cache invalidation', async () => {
        let cache = new Cache(new SimpleCacheStorage())

        /* In case of cache miss, cache method should execute generator function
         * and store calculated value */
        let val1 = await cache.cache('testKey1', {}, () => {return 'TestValue'})
        assert.equal(val1, 'TestValue')

        /* invalidate method should remove key from cache storage */
        await cache.invalidate('testKey1')

        /* In case of cache miss, cache method should execute generator function
         * and store calculated value */
        let val2 = await cache.cache('testKey1', {}, () => {return 'AnotherTestValue'})
        assert.equal(val2, 'AnotherTestValue')
    });


    it('Working with data structures', async () => {
        let cache = new Cache(new SimpleCacheStorage())

        // Caching array
        let val1 = await cache.cache('testKey1', {}, () => {return [1, 2, 3]})
        assert.deepEqual(val1, [1, 2, 3])
        val1 = await cache.cache('testKey1', {}, () => {return 'Wrong value'})
        assert.deepEqual(val1, [1, 2, 3])

        // Caching hashmap
        let val2 = await cache.cache('testKey2', {}, () => {return {a: 1, b: 2}})
        assert.deepEqual(val2, {a: 1, b: 2})
        val2 = await cache.cache('testKey2', {}, () => {return 'Wrong value'})
        assert.deepEqual(val2, {a: 1, b: 2})
    });
});
