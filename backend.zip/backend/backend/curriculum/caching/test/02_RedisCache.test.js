import assert  from 'assert';
import { Cache, RedisCacheStorage }  from '../src/cache.js';
import Redis from 'ioredis';

const redis = new Redis("redis://redis:6379/")

describe('Redis Cache Storage', () => {
    beforeEach(async () => { await redis.flushall() })

    it('Get and Set', async () => {
        let storage = new RedisCacheStorage(redis)
        
        let val = await storage.get('testKey')
        assert.equal(val, null)

        await storage.set('testKey','TestValue')

        val = await storage.get('testKey')
        assert.equal(val, 'TestValue')
    });

    it('Remove key', async () => {
        let storage = new RedisCacheStorage(redis)
        
        await storage.set('testKey','TestValue')

        await storage.del('testKey','TestValue')

        let val = await storage.get('testKey')
        assert.equal(val, null)
    });

    it('Get TTL', async () => {
        let storage = new RedisCacheStorage(redis)

        assert.equal(await storage.ttl('testKey'), -2)
        
        await storage.set('testKey','TestValue')

        assert.equal(await storage.ttl('testKey'), -1)

        await storage.set('testKey','TestValue', {ttl: 1})
        assert.equal(await storage.ttl('testKey'), 1)
    });
});

describe('Redis Cache', () => {
    beforeEach(async () => { await redis.flushall() })
    after(async () => { await redis.quit() })

    it('Caching', async () => {
        let cache = new Cache(new RedisCacheStorage(redis))

        let val1 = await cache.cache('testKey1', {}, () => {return 'TestValue'})
        assert.equal(val1, 'TestValue')

        let val2 = await cache.cache('testKey1', {}, () => {return 'AnotherTestValue'})
        assert.equal(val2, 'TestValue')
    });

    it('Cache invalidation', async () => {
        let cache = new Cache(new RedisCacheStorage(redis))

        let val1 = await cache.cache('testKey1', {}, () => {return 'TestValue'})
        assert.equal(val1, 'TestValue')

        await cache.invalidate('testKey1')

        let val2 = await cache.cache('testKey1', {}, () => {return 'AnotherTestValue'})
        assert.equal(val2, 'AnotherTestValue')
    });

    it('Time to live', async () => {
        let cache = new Cache(new RedisCacheStorage(redis))

        let val1 = await cache.cache('testKey1', {ttl: 1}, () => {return 'TestValue1'})
        assert.equal(val1, 'TestValue1')

        let val2 = await cache.cache('testKey1', {}, () => {return 'AnotherTestValue'})
        assert.equal(val2, 'TestValue1')

        await new Promise(resolve => setTimeout(resolve, 1001));

        let val3 = await cache.cache('testKey1', {}, () => { return 'AnotherTestValue'})
        assert.equal(val3, 'AnotherTestValue')
    });

    it('Serialization', async () => {
        let cache = new Cache(new RedisCacheStorage(redis))

        // Caching array
        let val1 = await cache.cache('testKey1', {}, () => {return [1, 2, 3]})
        assert.deepEqual(val1, [1, 2, 3])
        val1 = await cache.cache('testKey1', {}, () => {return 'Wrong value'})
        assert.deepEqual(val1, [1, 2, 3])

        // Caching hashmap
        let val2 = await cache.cache('testKey2', {}, () => {return {a: 1, b: 2}})
        assert.deepEqual(val2, {a: 1, b: 2})
        val2 = await cache.cache('testKey2', {}, () => {return 'Wrong value'})
        assert.deepEqual(val2, {a: 1, b: 2})
    });


    it('Advanced: Concurrency requests', async () => {
        let cache = new Cache(new RedisCacheStorage(redis))

        let prom1 = cache.cache('testKey1', {}, async () => {
            await new Promise(resolve => setTimeout(resolve, 10))
            return 'TestValue1'
        })

        let prom2 = cache.cache('testKey1', {}, async () => {
            await new Promise(resolve => setTimeout(resolve, 10))
            return 'AnotherTestValue'
        })

        let val1 = await prom1
        let val2 = await prom2

        assert.equal(val1, 'TestValue1')
        assert.equal(val2, 'TestValue1')
    });

    it('Advanced: Cache warm up', async () => {
        let cache = new Cache(new RedisCacheStorage(redis))

        let initVal = await cache.cache('testKey1', {ttl: 2, warmUpTTL: 1}, () => {return 'TestValue'})
        assert.equal(initVal, 'TestValue')

        //Warm Up wasn't triggered too early
        initVal = await cache.cache('testKey1', {ttl: 2, warmUpTTL: 1}, () => {return 'AnotherTestValue'})
        assert.equal(initVal, 'TestValue')

        await new Promise(resolve => setTimeout(resolve, 1000))

        // Making concurrent request ot cache library
        let prom1 = cache.cache('testKey1', {ttl: 2, warmUpTTL: 1}, async () => {
            await new Promise(resolve => setTimeout(resolve, 10))
            return 'NewTestValue'
        })

        let prom2 = cache.cache('testKey1', {ttl: 2, warmUpTTL: 1}, async () => {
            await new Promise(resolve => setTimeout(resolve, 10))
            return 'AnotherTestValue'
        })

        let val1 = await prom1
        let val2 = await prom2

        // First generated value should be returned for both requests
        assert.equal(val1, 'NewTestValue')
        assert.equal(val2, 'TestValue')

        let val3 = await cache.cache('testKey1', {ttl: 2, warmUpTTL: 1}, () => {return 'AnotherTestValue'})
        assert.equal(val1, 'NewTestValue')
    });
});
