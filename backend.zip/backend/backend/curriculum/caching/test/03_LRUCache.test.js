import assert  from 'assert';
import { Cache, LRUCacheStorage }  from '../src/cache.js';

describe('LRU Cache Storage', () => {
    it('Get and Set', async () => {
        let storage = new LRUCacheStorage()
        
        let val = await storage.get('testKey')
        assert.equal(val, null)

        await storage.set('testKey','TestValue')

        val = await storage.get('testKey')
        assert.equal(val, 'TestValue')
    });

    it('Remove key', async () => {
        let storage = new LRUCacheStorage()
        
        await storage.set('testKey','TestValue')

        await storage.del('testKey','TestValue')

        let val = await storage.get('testKey')
        assert.equal(val, null)
    });

    it('Get TTL', async () => {
        let storage = new LRUCacheStorage()

        assert.equal(await storage.ttl('testKey'), -2)
        
        await storage.set('testKey','TestValue')

        assert.equal(await storage.ttl('testKey'), -1)

        await storage.set('testKey','TestValue', {ttl: 1})
        assert.equal(await storage.ttl('testKey'), 1)
    });

    it('Keys rotation', async () => {
        let storage = new LRUCacheStorage(1)

        await storage.set('testKey','TestValue')
        
        await storage.set('testKey1','AnotherTestValue')
        assert.equal(await storage.get('testKey'), null)
    });
});

describe('LRU Cache', () => {
    it('Advanced: Caching', async () => {
        let cache = new Cache(new LRUCacheStorage())

        /* In case of cache miss, cache method should execute generator function
         * and store calculated value */
        let val1 = await cache.cache('testKey1', {}, () => {return 'TestValue'})
        assert.equal(val1, 'TestValue')

        /* In case of cache hit, cache method should return stored value */
        let val2 = await cache.cache('testKey1', {}, () => {return 'AnotherTestValue'})
        assert.equal(val2, 'TestValue')
    });

    it('Advanced: Cache invalidation', async () => {
        let cache = new Cache(new LRUCacheStorage())

        /* In case of cache miss, cache method should execute generator function
         * and store calculated value */
        let val1 = await cache.cache('testKey1', {}, () => {return 'TestValue'})
        assert.equal(val1, 'TestValue')

        /* invalidate method should remove key from cache storage */
        await cache.invalidate('testKey1')

        /* In case of cache miss, cache method should execute generator function
         * and store calculated value */
        let val2 = await cache.cache('testKey1', {}, () => {return 'AnotherTestValue'})
        assert.equal(val2, 'AnotherTestValue')
    });

    it('Advanced: Limiting number of keys', async () => {
        // Set limit of cache keys to 1
        let cache = new Cache(new LRUCacheStorage(1))

        /* In case of cache miss, cache method should execute generator function
         * and store calculated value */
        let val1 = await cache.cache('testKey1', {}, () => {return 'TestValue1'})
        assert.equal(val1, 'TestValue1')

        /* Because we set limit for number of keys to 1, and we use LRU police.
         * Previous key should be automatically removed */
        let val2 = await cache.cache('testKey2', {},() => {return 'TestValue2'})
        assert.equal(val2, 'TestValue2')

        // Checking that we don't have value for testKey1
        let val3 = await cache.cache('testKey1', {}, () => {return 'AnotherTestValue'})
        assert.equal(val3, 'AnotherTestValue')
    });

    it('Advanced: Time to live', async () => {
        let cache = new Cache(new LRUCacheStorage())

        // ttl parameter should provide possibility to define expiration time for cache key
        let val1 = await cache.cache('testKey1', {ttl: 1}, () => {return 'TestValue1'})
        assert.equal(val1, 'TestValue1')

        //Checking that key value is stored in cache memory
        let val2 = await cache.cache('testKey1', {}, () => {return 'AnotherTestValue'})
        assert.equal(val2, 'TestValue1')

        // Wait until expiration time will be reached
        await new Promise(resolve => setTimeout(resolve, 1001));

        // Checking that key was expired and we able to set new value
        let val3 = await cache.cache('testKey1', {}, () => { return 'AnotherTestValue'})
        assert.equal(val3, 'AnotherTestValue')
    });

    it('Advanced: Working with data structures', async () => {
        let cache = new Cache(new LRUCacheStorage())

        // Caching array
        let val1 = await cache.cache('testKey1', {}, () => {return [1, 2, 3]})
        assert.deepEqual(val1, [1, 2, 3])
        val1 = await cache.cache('testKey1', {}, () => {return 'Wrong value'})
        assert.deepEqual(val1, [1, 2, 3])

        // Caching hashmap
        let val2 = await cache.cache('testKey2', {}, () => {return {a: 1, b: 2}})
        assert.deepEqual(val2, {a: 1, b: 2})
        val2 = await cache.cache('testKey2', {}, () => {return 'Wrong value'})
        assert.deepEqual(val2, {a: 1, b: 2})
    });

    it('Advanced: Concurrency requests', async () => {
        let cache = new Cache(new LRUCacheStorage())

        // Making concurrent request ot cache library
        let prom1 = cache.cache('testKey1', {}, async () => {
            await new Promise(resolve => setTimeout(resolve, 10))
            return 'TestValue1'
        })

        let prom2 = cache.cache('testKey1', {}, async () => {
            await new Promise(resolve => setTimeout(resolve, 10))
            return 'AnotherTestValue'
        })

        let val1 = await prom1
        let val2 = await prom2

        // First generated value should be returned for both requests
        assert.equal(val1, 'TestValue1')
        assert.equal(val2, 'TestValue1')
    });

    it('Advanced: Cache warm up', async () => {
        let cache = new Cache(new LRUCacheStorage())

        let initVal = await cache.cache('testKey1', {ttl: 2, warmUpTTL: 1}, () => {return 'TestValue'})
        assert.equal(initVal, 'TestValue')

        //Warm Up wasn't triggered too early
        initVal = await cache.cache('testKey1', {ttl: 2, warmUpTTL: 1}, () => {return 'AnotherTestValue'})
        assert.equal(initVal, 'TestValue')

        await new Promise(resolve => setTimeout(resolve, 1000))

        // Making concurrent request ot cache library
        let prom1 = cache.cache('testKey1', {ttl: 2, warmUpTTL: 1}, async () => {
            await new Promise(resolve => setTimeout(resolve, 10))
            return 'NewTestValue'
        })

        let prom2 = cache.cache('testKey1', {ttl: 2, warmUpTTL: 1}, async () => {
            await new Promise(resolve => setTimeout(resolve, 10))
            return 'AnotherTestValue'
        })

        let val1 = await prom1
        let val2 = await prom2

        // First generated value should be returned for both requests
        assert.equal(val1, 'NewTestValue')
        assert.equal(val2, 'TestValue')

        let val3 = await cache.cache('testKey1', {ttl: 2, warmUpTTL: 1}, () => {return 'AnotherTestValue'})
        assert.equal(val1, 'NewTestValue')
    });
});
