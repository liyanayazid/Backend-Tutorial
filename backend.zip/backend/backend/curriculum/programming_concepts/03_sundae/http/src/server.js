const http      = require('http');
const stockSpan = require('./stock_span');

let server;

function serve(port) {
    throw new Error('Not implemented');
}

function stop() {
    throw new Error('Not implemented');
}

module.exports = {
    serve,
    stop,
};
