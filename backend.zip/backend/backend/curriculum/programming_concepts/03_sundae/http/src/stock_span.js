function stockSpan(stockPrices) {
    const stockSpan = [];
    stockSpan[0] = 1;
    
    for (let i = 1; i < stockPrices.length; i++) {
        let span = 1;
        for (let j = i - 1; j >= 0; j--) {
            if (stockPrices[i] > stockPrices[j]) {
                span = span + 1;
            } else {
                break;
            }
        }
        stockSpan[i] = span;
    }
    
    return stockSpan;
}

module.exports = stockSpan;
