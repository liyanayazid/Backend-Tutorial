const http = require('http');

function request(port, host, data) {
    throw new Error('Not implemented');
}

module.exports = {
    request,
};
