const { request }     = require('../src/client');
const { serve, stop } = require('../src/server');

describe('tests', () => {
    const data = JSON.stringify({
        stock_name  : 'AAPL',
        stock_prices: [100, 80, 60, 70, 60, 75, 85, 10, 4, 5, 90, 120, 80],
    });

    it('test 1', async () => {
        request(8080, 'localhost', data);
    });
});
