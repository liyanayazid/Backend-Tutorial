const index = require('../src/index');

describe('test', () => {
    it('should test', () => {
        expect(index()).toStrictEqual(1);
    });
});
