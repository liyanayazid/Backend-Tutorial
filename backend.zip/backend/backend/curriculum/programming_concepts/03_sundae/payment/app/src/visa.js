const { FeeStructure } = require('.');

class VisaAgent {
    feeStructure;

    constructor(feeStructure) {
        this.feeStructure = feeStructure;
    }

    getName() {
        throw new Error('Method not implemented.');
    }

    getFee(amount) {
        throw new Error('Method not implemented.');
    }
}

module.exports = VisaAgent;
