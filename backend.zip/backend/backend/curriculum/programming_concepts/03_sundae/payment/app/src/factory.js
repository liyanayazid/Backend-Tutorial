const { getDetailsFromJson }               = require('.');
const { PaymentAgentDetail, FeeStructure } = require('./index');
const PaymentAgent                         = require('./payment_agent');
const { VisaCreditAgent }                  = require('./visa_credit');

class PaymentAgentFactory {
    static getPaymentAgent(name) {
        const paymentAgentDetails = getDetailsFromJson();

        switch (name)   {
            case 'VisaCredit':
                return new VisaCreditAgent(PaymentAgentFactory.getFeeStructure(paymentAgentDetails, name));
                //... and so on

            default:
                throw new Error('Could not find payment agent');
        }
    }

    static getFeeStructure(paymentAgentDetails, agentName) {
        throw new Error('Not implemented');
    }
}

module.exports = {
    PaymentAgentFactory,
};
