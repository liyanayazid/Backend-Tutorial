function getDetailsFromJson() {
    throw new Error('Not implemented');
}

class FeeStructure {
    minAmt;
    maxAmt;
    feePercent;
    premium;

    constructor(minAmt, maxAmt, feePercent, premium) {
        this.minAmt     = minAmt;
        this.maxAmt     = maxAmt;
        this.feePercent = feePercent;
        this.premium    = premium;
    }
}


class PaymentAgentDetail {
    cardAgents;
    bankingAgents;
    walletAgents;

    constructor(cardAgents, bankingAgents, walletAgents) {
        this.cardAgents    = cardAgents;
        this.bankingAgents = bankingAgents;
        this.walletAgents  = walletAgents;
    }
}

class AgentDetail {
    name;
    feeStructure;

    constructor(name, feeStructure) {
        this.name         = name;
        this.feeStructure = feeStructure;
    }
}

class CardAgentDetail extends AgentDetail {
    type; // 'credit' or 'debit'

    constructor(name, feeStructure, type) {
        super(name, feeStructure);
        this.type = type;
    }
}

class BankingAgentDetail extends AgentDetail {}

class WalletAgentDetail extends AgentDetail {}

module.exports = {
    getDetailsFromJson,
    FeeStructure,
    PaymentAgentDetail,
};
