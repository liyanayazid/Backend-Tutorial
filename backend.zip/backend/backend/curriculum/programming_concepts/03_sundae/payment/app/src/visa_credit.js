const VisaAgent = require('./visa');

class VisaCreditAgent extends VisaAgent {
    
}

module.exports = VisaCreditAgent;
