# Sundae

### All these assignments will need [local installation and setup](https://github.com/besquare-deriv/backend/blob/main/installation_guide.md).

## Q1 - Payment Charges

**Note - This question is a group activity. You will be working with a group of 4 people.**

Deriv has multiple payment partners to fulfill the needs of its diverse customers. Each payment partner will charge some fee for facilitating the payment. Let us call these as _Payment Agents_. A payment agent can of a card payment agent, online banking payment agent, a online wallet payment agent, etc. Furthermore, each payment agent will have a different fee structure. There can be also multiple types of payment agents within a single type. For eg. a card payment agent can be Visa, Mastercard etc.

Your task is to implement an interface that will calculate the fee for a payment agent.

A list of payment agents with all the details is available in `./payment/payment_agents.json`. Below is the explanation of the JSON Schema
```
1. name - name of the payment agent (string)
2. type - type [credit/ debit] of the 'card' payment agent (string)
3. fee_structure - fee structure of the payment agent (complex data structure)
4. fee_structure.min_amount - minimum amount that can be facilitated by the payment agent per transaction (integer)
5. fee_structure.max_amount - maximum amount that can be facilitated by the payment agent per transaction (integer)
6. fee_structure.fee - percentage of transaction amount to be charged as fee per transaction (integer)
7. fee_structure.premium - fixed amount to be charged as fee per 'bank agent' transaction (integer)

Note: For banking agent(s) the maximum of fee percentage and premium will be considered as payment charges.
```

### Steps
- This is a big task. Determine how you will parse the JSON schema and relationships between the banking agents.
- Come up with a rough class diagram / architectural flow chart describing the solution.
- Try to implement OOP as much as possible.
- Try to follow TDD approach.
- Once you are set to write code, distribute the tasks within the group and use git to track your progress.
- For your reference, a sample sketch of how the code can look like is available in `./payment/app/`. However it is incomplete.


## Q2 - HTTP Server

**Note - This question is a group activity. You will be working with a group of 4 people.**

Deriv has lots and lots of APIs. APIs are very important if you want to build a service oriented and scalable platform. In this problem we will be implementing a simple HTTP server / client that will support an arbitrary API. In its lowest form, think of an API as a simple, idempotent function, that does precisely one and only one thing. All the necessary input data needed to execute the function is to be passed as an argument to the function itself.

We will be implementing an API for the [stock span problem](https://www.geeksforgeeks.org/the-stock-span-problem/) in this task. The `http-server` will host the logic to calculate the stock span for a given stock price. We will access this logic via the `http-client`.

Your function can take price list of a stock and the function should return the stock span for each day.

### Steps:
- Implement the `http-server` in `./http/src/server.js`
- Implement the stock span function.
- Implement the `http-client` in `./http/src/client.js`
- Write npm scripts to start the http-server
- Write tests to access the server using http-client
