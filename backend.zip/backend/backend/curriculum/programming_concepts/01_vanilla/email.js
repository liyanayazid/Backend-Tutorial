// do not change this function, it is needed to validate assertions you make
function assert(truth) {
    if (truth === false) {
        throw new Error('End of program');
    }
}


class Email {
    // list to hold all previous unique emails
    list;

    constructor(list) {
        Email.list = list;
    }

    insert(emailString) {
        emailString = emailString.split("@");
       const strBefore = emailString[0];
       const strAfter = emailString[1];
       const newBefore = strBefore.replace(/[-._]/g,"");
       var newEmail = newBefore + strAfter;

       if (Email.list.includes(newEmail)) {
           console.log(emailString + " is not a proper email");
       } else {
           Email.list.push(newEmail);
           console.log(newEmail);
       }
    }

    getList() {
        return Email.list;
    }

    seperate(emailString){
        email.subString(0, email.lastIndexOf("@"));


    }

    // you may add more methods to this class as needed
}

const email = new Email([]); // init with empty list of emails

email.insert('johndoe@gmail.com') // should insert
assert(email.getList().length === 1)

email.insert('j.o.h.n.d.o.e@gmail.com') // should print a warning on console.log
assert(email.getList().length === 1)

email.insert('john*doe@gmail.com')
assert(email.getList().length === 2)

email.insert('john*__-doe@gmail.com')
assert(email.getList().length === 2)
