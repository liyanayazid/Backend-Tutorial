# Vanilla

## Q1 - Duplicate Emails

Deriv uses emails for identifying unique users. Hence a user is able to register with a single email only once. However, clever users may find a way to create another account using same email by adding permitted special characters to their email. For example, many popular email providers like Gmail skip `.` while storing emails so that `jon.doe@gmail.com` and `jondoe@gmail` point to same address.

Now you can see why this is a problem. Since different email providers skip / allow different characters, users can have 2 accounts managed by same email address. As a regulatory measure, this is prohibited.

Your aim is to write a program that will store only truly unique email strings and throw an error if a user tries to save an existing email.

### Steps
- Open `email.js` in your IDE
- Complete code wherever needed
- Test by running `node email.js` in terminal

### Assumptions
- You can assume that there is only one service provider (Gmail) and that it will skip underscores, dots and hyphens (`_ , . , -`)
- You can assume that the email you receive is a valid email

### Bonus
- It will be great if you can solve this problem using methods and classes.

## Q2 - Buy / Sell Contract

For this problem, assume that you are trading a cryptocurrency (let's call it `BEQ`). The price of BEQ changes every second which is retrieved from a hashmap with the epoch time (seconds) being key and price in USD/BEQ being the value. _This is not how the market works, but let's assume the world is simple :)_. You have two functions (`sell` function and `buy` function) which takes in the epoch time (seconds) and quantity as input. There is also a `getBalance` function that returns the value of your portfolio in USD at current time. Since this is not a Nolan movie, we are also constrained by the fact that time (just like Thanos) is inevitable and the universal arrow of time only moves forward. That means if you call `buy` with time `T1` and thereafter sell with `T2` make sure that `T2 > T1` or else print a console log during buy/sell operation.

The value of your portfolio is determined by the sum of your current balance in USD with the quantity of BEQ times the currency rate at that instant \
`Net Balance [at T] = USD balance + BEQ qty * BEQ rate [at T]` \
This means time instant (in seconds) will be a parameter to `getBalance` method.

Your task is to implement the 3 functions mentioned above.

### Steps
- Open `crypto.js` in your IDE
- Complete code wherever needed
- Test by running `node crypto.js` in terminal

### Assumptions
- You can assume that you always call the buy/sell functions in correct order and with values of time.
- You can assume that you're an excellent investment manager and won't allow the net balance to dip below zero.
- You can assume the opening balance to be USD 10000.
- You can assume the opening BEQ quantity to be 0.
- You cannot sell without buying.

### Bonus
- It will be great if you can solve this problem using methods and classes.
- Also can you find out the time at which the price hits minima and maxima?
