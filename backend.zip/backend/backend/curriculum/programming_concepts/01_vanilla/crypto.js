// do not change this function, it is needed to validate assertions you make
function equals(value1, value2) {
  if (Math.abs(value1 - value2) > 0.0001) {
    throw new Error(`error margin: ${Math.abs(value1 - value2)}`);
  }
}

// prices!
const prices = new Map([
  [1, 32.4],
  [2, 31.8],
  [3, 30.3],
  [4, 31.6],
  [5, 33.4],
  [6, 32.5],
  [7, 32.4],
  [8, 32.7],
  [9, 32.1],
  [10, 31.9],
  [11, 31.1],
  [12, 30.6],
  [13, 29.7],
  [14, 29.9],
  [15, 31.0],
  [16, 32.1],
  [17, 32.6],
  [18, 32.8],
  [19, 33.3],
  [20, 33.4],
  [21, 33.7],
]);

class Trade {
  BALANCE = 10000;
  BEQ_QTY = 0;
  TIME = 0;

  sell(time, qty) {
    if (time > this.TIME) {
      this.TIME = time;
      this.BALANCE = this.BALANCE += qty * prices.get(time);
      this.BEQ_QTY = this.BEQ_QTY - +qty;
      console.log(
        "Current Balance: " +
          this.BALANCE +
          " " +
          "Quantity is " +
          " " +
          this.BEQ_QTY
      );
    } else {
      console.log("Not enough BEQ. Please buy");
    }
  }

  buy(time, qty) {
    if (time > this.TIME) {
      this.TIME = time;
      this.BALANCE = this.BALANCE -= qty * prices.get(time);
      this.BEQ_QTY = this.BEQ_QTY += qty;
      console.log(
        "Current Balance: " +
          this.BALANCE +
          " " +
          "Quantity is " +
          " " +
          this.BEQ_QTY
      );
    } else {
      console.log("INVALID");
    }
  }

  getBalance(time) {
    this.TIME = time;
    let balance = this.BALANCE + this.BEQ_QTY * prices.get(time);
    console.log("Net Balance is " + balance);
  }
}

const trade = new Trade();

// the beginning of time
equals(trade.getBalance(0), 10000); // starting balance

// 2 seconds later

trade.buy(2, 3.5); //buy function
equals(trade.getBalance(2), 10000);
equals(trade.getBalance(3), 9994.75);

// 5 seconds later
trade.sell(5, 1); //sell function
equals(trade.getBalance(5), 10005.6);

// 9 seconds later
trade.buy(9, 2.8);
equals(trade.getBalance(9), 10002.35);

// 13 seconds later
trade.buy(13, 4.1);
equals(trade.getBalance(13), 9989.63);

// trying to buy at T = 8 now, print warning and do not perform any operation
trade.buy(8, 7.6);

// 21 seconds later
trade.sell(21, 9);
equals(trade.getBalance(21), 10027.23);
