let customer = {
  name: 'Ivan',
  rentals: [
    {movieID: 'F001', days: 1 },
    {movieID: 'F003', days: 4},
    {movieID: 'F004', days: 1},
  ],
};

let movies = {
  F001: { title: 'Ran', code: 'regular' },
  F002: { title: 'Trois Couleurs: Bleu', code: 'regular' },
  F003: { title: 'Cars 2', code: 'childrens' },
  F004: { title: 'Latest Hit Release', code: 'new' },
  //EXERCISE NOTE: add more movies if you need
};

let totalAmount = 0;
let frequentRenterPoints = 0;
let result = `Rental Record for ${customer.name}\n`;
for (let r of customer.rentals) {
  let movie = movies[r.movieID];
  let thisAmount = 0;

  switch (movie.code) {
    case 'regular':
      thisAmount = 2;
      if (r.days > 2) {
        thisAmount += (r.days - 2) * 1.5;
      }
      break;
    case 'new':
      thisAmount = r.days * 3;
      break;
    case 'childrens':
      thisAmount = 1.5;
      if (r.days > 3) {
        thisAmount += (r.days - 3) * 1.5;
      }
      break;
  }


  frequentRenterPoints++;
  if (movie.code === 'new' && r.days > 2) frequentRenterPoints++;

  result += `\t${movie.title}\t${thisAmount}\n`;
  totalAmount += thisAmount;
}

result += `Amount owed is ${totalAmount}\n`;
result += `You earned ${frequentRenterPoints} frequent renter points\n`;

console.log(result);