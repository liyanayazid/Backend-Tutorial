const { valid, card } = require('./luhn');

describe('Luhn', () => {
  it('single digit strings can not be valid', () => {
    expect(valid('1')).toBeFalsy()
  })

  it('a single zero is invalid', () => {
    expect(valid('0')).toBeFalsy()
  })

  it('a simple valid SIN that remains valid if reversed', () => {
    expect(valid('059')).toBeTruthy()
  })

  it('a valid Canadian SIN', () => {
    expect(valid('055 444 285')).toBeTruthy()
  })

  it('invalid Canadian SIN', () => {
    expect(valid('055 444 286')).toBeFalsy()
  })

  it('invalid credit card', () => {
    expect(valid('8273 1232 7352 0569')).toBeFalsy()
  })

  it('valid strings with a non-digit included become invalid', () => {
    expect(valid('055a 444 285')).toBeFalsy()
  })

  it('valid strings with punctuation included become invalid', () => {
    expect(valid('055-444-285')).toBeFalsy()
  })

  it('valid strings with symbols included become invalid', () => {
    expect(valid('055£ 444$ 285')).toBeFalsy()
  })

  it('single zero with space is invalid', () => {
    expect(valid(' 0')).toBeFalsy()
  })

  it('input digit 9 is correctly converted to output digit 9', () => {
    expect(valid('091')).toBeTruthy()
  })
})


// remove 'x' if you want to run them
describe('Bonus', () => {
  it('visa', () => {
    expect(card('4160 3458 4854 0000')).toStrictEqual('Visa');
    expect(card('4160 3458 4854')).toStrictEqual('Invalid');
  });

  it('mastercard', () => {
    expect(card('5160 3458 4854 0000')).toStrictEqual('Mastercard');
    expect(card('5260 3458 4854 0000')).toStrictEqual('Mastercard');
    expect(card('5360 3458 4854 0000')).toStrictEqual('Mastercard');
    expect(card('5460 3458 4854 0000')).toStrictEqual('Mastercard');
    expect(card('5560 3458 4854 0000')).toStrictEqual('Mastercard');
    expect(card('5660 3458 4854 0000')).toStrictEqual('Invalid');
  });

  it('discover', () => {
    expect(card('6011 3458 4854 0000')).toStrictEqual('Discover');
    expect(card('6440 3458 4854 0000')).toStrictEqual('Discover');
    expect(card('6540 3458 4854 0000')).toStrictEqual('Discover');
  });

  
  it('amex', () => {
    expect(card('3411 3458 4854 0000')).toStrictEqual('Amex');
    expect(card('3740 3458 4854 0000')).toStrictEqual('Amex');
  });
});
