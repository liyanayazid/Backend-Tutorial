function valid(num) {
  // check
  let regexNum = /[^0-9\s]+/;
  if (regexNum.test(num)) {
    return false;
  }

  // luhn algorithm
  let sum = 0;
  let doubleNum = false; //
  num = num.replace(/\D/g, ""); 
  
  for (let i = num.length - 1; i >= 0; i--) {
    let numString = num.charAt(i);
    let numInt = parseInt(numString, 10);

    if (doubleNum && (numInt *= 2) > 9) {
      numInt -= 9;
    }

    sum += numInt;
    doubleNum = !doubleNum;
  }

  return sum !== 0 && sum % 10 == 0;
}

function card(num) {
  throw new Error("Implement this method");
}

module.exports = {
  valid,
  card,
};
