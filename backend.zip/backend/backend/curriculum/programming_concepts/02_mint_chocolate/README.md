# Mint Chocolate

### All these assignments will need [local installation and setup](https://github.com/besquare-deriv/backend/blob/main/installation_guide.md).

## Q1 - Credit Card

Ever tried to sneak past some signup pages by putting fake credit card numbers? You probably cannot because we can actually validate if a credit card number is valid or not (without having a database of all credit card numbers) with the help of [Luhn's Algorithm](https://en.wikipedia.org/wiki/Luhn_algorithm)

Luhn algorithm also helps to determine validity of Canadian Social Identification Numbers (SIN).

In this problem, you have to implement the Luhn's algorithm in JavaScript.

### Example

_Strings of length 1 or less are not valid. Spaces are allowed in the input, but they should be stripped before checking. All other non-digit characters are disallowed._

**Example 1:** valid credit card number \
`4539 3195 0343 6467` \
The first step of the Luhn algorithm is to double every second digit, starting from the right. We will be doubling \
`4_3_ 3_9_ 0_4_ 6_6_` \
If doubling the number results in a number greater than 9 then subtract 9 from the product. The results of our doubling: \
`8569 6195 0383 3437` \
Then sum all of the digits: \
`8+5+6+9+6+1+9+5+0+3+8+3+3+4+3+7 = 80` \
If the sum is evenly divisible by 10, then the number is valid. **This number is valid!**

**Example 2:** invalid credit card number \
`8273 1232 7352 0569` \
Double the second digits, starting from the right \
`7253 2262 5312 0539` \
Sum the digits \
`7+2+5+3+2+2+6+2+5+3+1+2+0+5+3+9 = 57` \
57 is not evenly divisible by 10, so this number is **not valid**.


### Steps
- Change your working directory to `./credit_card`
- Run `npm install`
- Implement your code in `luhn.js`
- Check out the tests in `luhn.test.js` and run them with `npm test`
- Try to have all tests as "_passed_".

### Bonus
- Given the reference below try to find out which provider the card belongs to by implementing the `card` method
```
Visa: 4xxxxx
Mastercard: 51xxxx-55xxxx
Discover: 6011xx, 644xxx, 65xxxx
Amex: 34xxxx, 37xxxx
```

## Q2 - Custom Mapper

This assignment is all about special function on arrays. It is possible to perform bulk operations of entire arrays using the builtin `map` method. For example:
```js
const nums = [1, 2, 3, 4];

const square = (n) => {
    return n * n;
}; // simple squared method

const squared_nums = nums.map(square); // [1, 4, 9, 16]
```

Your task is to implement this `map` method without using any builtin JavaScript methods.

### Constraints
- Your custom method should be able to handle arrays of all types of data
- Your custom method should be able to perform any operation possible on element of this type in the array

### Steps
- Change your working directory to `./custom_map`
- Run `npm install`
- Implement your code in `map.js`
- Check out the tests in `map.test.js` and run them with `npm test`
- Try to have all tests as "_passed_".
