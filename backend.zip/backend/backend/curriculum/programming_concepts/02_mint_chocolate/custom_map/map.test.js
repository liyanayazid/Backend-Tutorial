const { customMap } = require('./map');

describe('customMap()', () => {
  it('accumulation empty', () => {
    const accumulator = (e) => e * e;
    expect(customMap([], accumulator)).toEqual([]);
  });

  it('customMap squares', () => {
    const accumulator = (n) => n * n;
    const result = customMap([1, 2, 3], accumulator);
    expect(result).toEqual([1, 4, 9]);
  });

  it('customMap upcases', () => {
    const accumulator = (word) => word.toUpperCase();
    const result = customMap('hello world'.split(/\s/), accumulator);
    expect(result).toEqual(['HELLO', 'WORLD']);
  });

  it('customMap reversed strings', () => {
    const accumulator = (word) =>
      word.split('').reverse().join('');
    const result = customMap(
      'the quick brown fox etc'.split(/\s/),
      accumulator
    );
    expect(result).toEqual(['eht', 'kciuq', 'nworb', 'xof', 'cte']);
  });

  it('customMap recursively', () => {
    const result = customMap('a b c'.split(/\s/), (char) =>
      customMap('1 2 3'.split(/\s/), (digit) => char + digit)
    );

    expect(result).toEqual([
      ['a1', 'a2', 'a3'],
      ['b1', 'b2', 'b3'],
      ['c1', 'c2', 'c3'],
    ]);
  });
});
