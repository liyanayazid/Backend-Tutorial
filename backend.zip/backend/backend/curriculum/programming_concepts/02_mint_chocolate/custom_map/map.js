function customMap(collection, mapper) {
  const array = [];
  for (let i = 0; i < collection.length; i++) {
    const anw = mapper(collection[i]);
    array.push(anw);
  }
  return array;
}

module.exports = {
  customMap,
};
