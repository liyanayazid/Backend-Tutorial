# REST API Projects
Please do some research and discuss with your team about the possible ways to do the following projects as well as finding the solution for each part.

## 1. Client
Retrieve the list of symbols and display in output using the API described at https://api.blockchain.com/v3/#/unauthenticated/getSymbols

### Steps
1. Create the following folders in your working directory:
    ```
    GroupX/MyName/
    └── API
        └── REST
            └── Client
    ```
2. Write your code in one or more `.js` file(s) inside `Client` folder.
4. Please `commit` and `push` your changes once finished. Use a descriptive commit message that clearly explain the changes that commit introduces.

An example of the output:

![REST Client](./images/rest_client.png)

---

## 2. Server
Create a REST API server to manage users' information.

Each user's information contains:
```json5
{
    email    : "useremail@domain.com",  // Required
    firstName: "...",
    lastName : "...",
    age      : 20,
    languages: ["...", "...", ...],
}
```

The API user should be able to do the following actions:
- Add a new user
- Retrieve the list of users
- Retrieve the detailed information of a given user by email if exists, otherwise an error.
- Update a user's information
- Delete a user

Bonus:
- Add search feature so that giving one or more fields, it returns the list of matching users.
- What other feature you'd add to the above list? Implement it.

### Notes
- `email` is required, so the API should return an error in case it's missing.
- You can store the information in memory.
- Define the "endpoint"s of your choice.
- In order to test and interact with the API, you may use `curl` or any other application of your choice.

### Steps
1. Create the following folder in your working directory:
    ```
    GroupX/MyName/
    └── API
        └── REST
            └── Server
    ```
2. Go to the `Server` folder and create a `package.json` file using `npm` commands. (search online to find the documents)
3. Use any node module or npm package of your choice.
4. Please remember to `commit` and `push` your changes as you progress. Use descriptive commit messages that clearly explain the changes each commit introduces.
