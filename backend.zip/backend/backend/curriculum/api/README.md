# API

## Table of contents
- [What is an API?](#what-is-an-api)
    - [A simple example](#a-simple-example)
    - [Real-life examples](#real-life-examples)
- [Importance of an API](#importance-of-an-api)
- [JSON](#json)
    - [Advantages](#advantages)
    - [Data types](#data-types)
    - [Example](#example)
- [Main types of Web APIs](#main-types-of-web-apis)
- [API protocols](#api-protocols)
    - [REST API](#rest-api)
        - [HTTP request methods](#http-request-methods)
        - [Test tools](#test-tools)
        - [Hands-on exercise](#hands-on-exercise)
    - [WebSocket API](#websocket-api)
        - [Test tools](#test-tools-1)
        - [Hands-on exercise](#hands-on-exercise-1)
    - [REST vs. WebSocket](#rest-vs-websocket)
- [Best practices](#best-practices)
- [API documentation](#api-documentation)
- [References](#references)


## What is an API?
API is the acronym for Application Programming Interface, which is a software intermediary that allows two applications to talk to each other. Each time you use an app like Facebook, send an instant message, or check the weather on your phone, you’re using an API.

API simplifies programming by abstracting the underlying implementation and only exposing objects or actions the developer needs.

![What is API](../images/api/what-is-api.png)

### A simple example
Imagine you’re sitting at a table in a restaurant with a menu of choices to order from. The kitchen is the part of the “system” that will prepare your order. What is missing is the critical link to communicate your order to the kitchen and deliver your food back to your table. That’s where the waiter or API comes in. The waiter is the messenger – or API – that takes your request or order and tells the kitchen – the system – what to do. Then the waiter delivers the response back to you; in this case, it is the food.
>Watch [What Are APIs?](https://youtu.be/OVvTv9Hy91Q)

### Real-life examples
When you use an application on your mobile phone, the application connects to the Internet and sends data to a server. The server then retrieves that data, interprets it, performs the necessary actions and sends it back to your phone. The application then interprets that data and presents you with the information you wanted in a readable way. This is what an API is - all of this happens via API.

Here is another example. You may be familiar with the process of searching flights online. Just like the restaurant, you have a variety of options to choose from, including different cities, departure and return dates, and more. Let us imagine that you’re booking you are flight on an airline website. You choose a departure city and date, a return city and date, cabin class, as well as other variables. In order to book your flight, you interact with the airline’s website to access their database and see if any seats are available on those dates and what the costs might be.

## Importance of an API

> *Building an application with no APIs is basically like building a house with no doors. The API for all computing purposes is how you open the blinds and the doors and exchange information. - **Josh Walker***

- **Decrease development time**

  APIs can be a service for developers. Every time developers write a new program, they don’t have to start from scratch to build a core application that tries to do everything. Instead, they can contract out certain responsibilities by using already created pieces that do the job better.

- **Integration with other systems**

  Having a seamless API integration platform allows businesses to leverage existing application functions with other systems and applications. APIs facilitate the connection between applications and let those systems exchange data. Nowadays, in the app-connected world, API integration is critical to all organizations.

- **Cross platform**

  Designing APIs based on a set of well-defined standards helps with accessing them regardless of device/platform.

- **Hide complexity**

  The API users don't have to be worry about behind the scenes. They only need to use the APIs to build their applications. 

- **Extend functionality**

  Developers can use web APIs to extend the functionality of their apps or websites.

- **Security**

  Although APIs can present a security risk if not implemented correctly, you can also use these tools to improve your overall security. There are also security APIs to be used like:

  NOTE: The following items are listed just as examples and none of them is used by Deriv.

  - [IBM API Connect](https://www.ibm.com/cloud/api-connect/secure)
  - [Google Safe Browsing API](https://developers.google.com/safe-browsing)
  - [Web Risk](https://cloud.google.com/web-risk)
  - [Website Malware Scanner API](https://quttera.com/quttera-web-malware-scanner-api)
  - [urlscan.io API](https://urlscan.io/docs/api/)

## JSON
JSON (**J**ava**S**cript **O**bject **N**otation) is a very common data format, with a diverse range of support. It's mainly used for transmitting serialized data over the network connection like many APIs.

JSON uses human-readable text to store and transmit data objects consisting of attribute–value pairs and array data types (or any other serializable value). It's been used as a file format as well as data interchange.

### Advantages
- Light-weight
- Easy to read and write
- Language-independent
- Simple and fast

### Data types
- **Number:** The format makes no distinction between integer and floating-point.
- **String:** A sequence of zero or more Unicode characters. Strings are delimited with double-quotation marks `""` and support a backslash escaping syntax.
- **Boolean:** Either of the values `true` or `false`.
- **Array:** An ordered list of zero or more values, each of which may be of any type. Arrays use square bracket notation `[]` with comma-separated elements.
- **Object:** A collection of key–value pairs where the names (also called properties) are strings. Each key is unique within an object. Objects are delimited with curly brackets `{}` and use commas to separate each pair, while within each pair the colon character `:` separates the key or name from its value.
- **null:** An empty value, using the word `null`.

### Example
A possible JSON representation describing a person:
```js
{
    "firstName": "John",
    "lastName": "Smith",
    "isAlive": true,
    "age": 27,
    "address": {
        "streetAddress": "21 2nd Street",
        "city": "New York",
        "state": "NY",
        "postalCode": "10021-3100"
    },
    "phoneNumbers": [
        {
          "type": "home",
          "number": "123 456-7890"
        },
        {
          "type": "office",
          "number": "555 123-4567"
        }
    ],
    "children": [],
    "spouse": null
}
```

>[JSON Editor Online](http://jsoneditoronline.org/#left=cloud.116afc7626b440dbb5cba9f87d67567f)

>Watch [JSON Crash Course](https://youtu.be/wI1CWzNtE-M)

## Main types of Web APIs

There are four main types of Web APIs:

- **Open APIs:** Also known as Public API, there are no restrictions to access these types of APIs because they are publicly available.
- **Partner APIs:** A developer needs specific rights or licenses in order to access this type of API because they are not available to the public.
- **Internal APIs:** Also known as Private APIs, only internal systems expose this type of API. These are usually designed for internal use within a company. The company uses this type of API among the different internal teams to be able to improve its products and services.
- **Composite APIs:** This type of API combines different data and service APIs. It is a sequence of tasks that run synchronously as a result of the execution, and not at the request of a task. Its main uses are to speed up the process of execution and improve the performance of the listeners in the web interfaces.

## API protocols
To leverage the different types of APIs, we must follow certain protocols. A protocol provides defined rules for API calls. It specifies the accepted data types and commands.

### REST API
REST (Representational State Transfer) is a web services API.

For an API to be RESTful, it must adhere to certain architectural constraints, or principles, including:

- **Stateless:** A REST API is stateless in nature, Client-Server Architecture.
- **Uniform Interface:** A client and server should communicate with one another via HTTP (HyperText Transfer Protocol) using URIs (Unique Resource Identifiers), CRUD (Create, Read, Update, Delete), and JSON (JavaScript Object Notation) conventions.
- **Client-Server:** The client and server should be independent of each other. The changes you make on the server shouldn’t affect the client and vice versa.
- **Cache:** The client should cache the responses as this improves the user experience by making them faster and more efficient.
- **Layered:** The API should support a layered architecture, with each layer contributing to a clear hierarchy. Each layer should be loosely coupled and allow for encapsulation.

![REST API](../images/api/rest-api.png)

#### HTTP request methods
- CRUD operations:
    - [`POST`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/POST): Create
    - [`GET`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/GET): Read
    - [`PUT`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/PUT): Update / Replace
    - [`DELETE`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/DELETE): Delete
- [`PATCH`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/PATCH): Partial Update / Modify
- [`HEAD`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/HEAD): Headers
- [`OPTIONS`](https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/OPTIONS): permitted communication options including the allowed methods

>Watch [Intro to REST](https://youtu.be/llpr5924N7E)

#### Test tools
There are various tools that simply allow testing APIs without the need of coding. Some of them listed below, you may find more alternatives online:

- [Postman API Client](https://www.postman.com/product/api-client/)
- [Hoppscotch](https://hoppscotch.io/) (formerly "PostWoman")

#### Hands-on exercises
**Exercise 1:**

Retrieve the list of symbols and display in output using the API described at https://api.blockchain.com/v3/#/unauthenticated/getSymbols

**Exercise 2:**

Create a REST API server to manage users' information.

>Please refer to [REST API Projects](./Project_Rest.md) for detailed information.


### WebSocket API
The WebSocket API provides full-duplex communication channels over a single TCP connection and makes it possible to open a two-way interactive communication session between the user's application or browser and the server. With this API, client code can send messages to a server and receive event-driven responses without having to poll the server for a reply.

![WebSocket API](../images/api/websockets-diagram.png)

#### Test tools
There are various tools that simply allow testing APIs without the need of coding. Some of them listed below, you may find more alternatives online:

- [WebSocket King Client](https://websocketking.com/) (Web)
- [WebSocket King Client](https://chrome.google.com/webstore/detail/websocket-king-client/cbcbkhdmedgianpaifchdaddpnmgnknn) (Browser extension)
- [WebSocket Test Client](https://chrome.google.com/webstore/detail/websocket-test-client/fgponpodhbmadfljofbimhhlengambbn) (Browser extension)
- [Smart WebSocket Client](https://chrome.google.com/webstore/detail/smart-websocket-client/omalebghpgejjiaoknljcfmglgbpocdp) (Browser extension)
- [WebSocket Client](https://www.microsoft.com/en-us/p/websocket-client/9p65mnb62734?) (Windows)
- [WebSocket Client](https://websocket-client.com/) (MacOS)
- [WebSocket Debug Tool](http://jxy.me/websocket-debug-tool/) (Web)

### REST vs. WebSocket

|REST API                                      |WebSocket API                                                  |
|:--------------------------------------------:|:-------------------------------------------------------------:|
|Stateless                                     |Stateful                                                       |
|Uni-directional                               |Bi-directional                                                 |
|Request-response model                        |Full-duplex model                                              |
|Slower                                        |Faster                                                         |
|New TCP connection for each HTTP request      |Only single TCP connection                                     |
|Horizontal and vertical scaling               |Vertical scaling                                               |
|HTTP request contains headers like head, title|Suitable for real time applications, does not have any overhead|

![REST vs. WebSocket](../images/api/rest-vs-websocket.png)

#### Hands-on exercise
Create a WebSocket API server that generates random numbers on every time interval based on the request it receives.

>Please refer to [WebSocket API Project](./Project_WebSocket.md) for detailed information.


## Best practices

- Avoid mirroring the internal structure of the data source.
- Avoid anti-patterns. E.g. to balance between:
    - Chatty API: The client application has to send multiple requests to find all the data that it requires.
    - Extraneous Fetching: Returning too much extra data that client doesn't need.
- Filter, Paginate, Sort: Prevent fetching large amounts of data when only a subset of the information is required.
- Error handling: To eliminate confusion for API users when an error occurs, it should handle errors gracefully and return HTTP response codes that indicate what kind of error occurred.
- Security: To maintain good security practices.
- Caching: In order to improve the performance.
- Service evolution: Provide backward compatibility. Client applications should continue to function without modification while allowing new client applications to take advantage of new features.
    - Evolve independently of client applications
    - Versioning
- [Documentation](#api-documentation): Reference, Tutorial, How To, Change Log

## API documentation
No matter how many opportunities for creating or extending software products API gives, it would remain an unusable piece of code if developers didn't understand how to work with it. Well-written and structured API documentation that explains how to effectively use and integrate an API in an easy-to-comprehend manner will make a developer happy and eager to recommend the API to peers.

The API documentation is a reference manual with all needed information about the API.

Numerous content elements make a good documentation, such as:

- Quick start guide
- Tutorials
- Authentication information
- Explanations for every API call (request)
- Examples of every request and return with a response description, error messages, etc.
- Samples of code for popular programmatic languages.

Documentation could be static and interactive. The latter allows for trying out APIs and see return results along with their descriptions.

Generation is the process of documenting APIs by developers and technical writers. The specialists may use API documentation solutions. (Tools like [Swagger](https://swagger.io/solutions/api-documentation/), [Postman](https://www.postman.com/api-documentation-tool/), [Slate](https://docs.slatejs.org/#documentation), [ReDoc](https://redoc.ly/), etc.)

## References
- https://en.wikipedia.org/wiki/API
- https://en.wikipedia.org/wiki/JSON
- https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/JSON
- https://en.wikipedia.org/wiki/Representational_state_transfer
- https://developer.mozilla.org/en-US/docs/Web/API/WebSockets_API
- https://en.wikipedia.org/wiki/WebSocket
