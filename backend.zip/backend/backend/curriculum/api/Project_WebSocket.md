# WebSocket API Project
Please do some research and discuss with your team about the possible ways to do the following project as well as finding the solution for each part.

Please remember to `commit` and `push` your changes as you progress. Use descriptive commit messages that clearly explain the changes each commit introduces.

## Description
Create a WebSocket API server that generates random numbers on every time interval based on the request it receives.

- The request structure to **start** receiving random numbers:
    ```js
    {
        "action"  : "start",    // Required - The action name to trigger
        "min"     : 0,          // Optional, integer, default: 0   - The minimum value of random numbers to generate
        "max"     : 100,        // Optional, integer, default: 100 - The maximum value of random numbers to generate
        "interval": 1           // Optional, integer, default: 1   - The time interval between responses, in "second"
    }
    ```
- To **stop** receiving random numbers:
    ```js
    {
        "action": "stop"    // required - The action name to trigger
    }
    ```

### Steps
1. Create the following folder in your working directory:
    ```
    GroupX/MyName/
    └── API
        └── WebSocket
    ```
2. Go to the `WebSocket` folder and create a `package.json` file using `npm` commands. (search online to find the documents)
3. Create server and client code.
    - Alternatively, use one of the [client test tools](./README.md#test-tools-1) to connect (`ws://localhost:3000`) and send requests according to the above specifications.
4. Use any node module or npm package of your choice.
5. Please remember to `commit` and `push` your changes as you progress. Use descriptive commit messages that clearly explain the changes each commit introduces.

### Example
This is just an example to demonstrate how it will work. The colors are only for differentiating between different messages sent or received and is not required.

- **Server**

    ![WebSocket Server](./images/websocket_server.png)

- **Client**

    ![WebSocket Client](./images/websocket_client.png)
