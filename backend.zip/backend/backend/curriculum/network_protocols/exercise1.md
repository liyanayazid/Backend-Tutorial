# Wireshark Lab - Exercise 1 - Ping

**Ping** is a useful utility to check for remote servers&#39; connectivity.

To use it, run the command line terminal. [This page](https://linux.die.net/man/8/ping) explains the syntax of the `ping` command.

Now, we can try to `ping <address>` using the command line. By default, ping sends 4 requests and waits for a **pong** answer in Windows. In Linux will run indefinitely until a keyboard interrupt is received.

![](./media/ping1.png)

In the command line above, I&#39;ve written the command **ping** [**www.google.com**](http://www.google.com/) **.**

We can see that Google has responded with four replies. The time it took for the message to return varied between 24 and 25 milliseconds. TTL means **time to live**. It is a value on an ICMP packet that prevents that packet from propagating back and forth between hosts ad infinitum

Ping is useful to determine whether a remote service is available, and how fast it is to reach that service. If it takes a very long time to reach a reliable server such as google.com, we might have a connectivity problem.

Run the following command from your command line (or terminal):

```sh
ping -c 1 www.google.com
```

---------------------------------------

### Use wireshark to answer the following questions:

1) What protocol does the **ping** utility use?

2) Using only wireshark, compute the **RTT** (Round Trip Time) – how long it took since your ping request was sent and until the ping reply was received?

Next, run the following command:

```sh
ping -c 1 -s 64 www.google.com
```

3) What is the main difference between the packet sent by this command, and the packet sent by the previous command? Where in wireshark can you see this difference, inspecting the packets?

4) What is the content (data) provided in the ping request packet? What is the content provided in the ping response packet?
