#!/bin/bash

[ "$PGPORT" ] && [ "$PGDATABASE" ] || {
    cat <<EOF
Please set PGPORT and PGDATABASE before running this script.

Example:

    export PGPORT=5434
    export PGDATABASE=besquare
EOF
    exit 1
}

sudo -u postgres PGPORT="$PGPORT" PGDATABASE="$PGDATABASE" \
     psql -v p_client_loginid=CL01 \
          -v p_market_type=financial \
          -v p_client_type=old \
          -e -f "${0%.sh}".sql
