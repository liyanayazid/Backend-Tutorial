INSERT INTO transaction.account (client_loginid, currency_code, binary_user_id)
VALUES ('CL01', 'USD', 1)
     , ('CL02', 'USD', 1)
     , ('CL03', 'USD', 2)
     , ('CL04', 'USD', 2)
     , ('CL05', 'USD', 3)
;

INSERT INTO betonmarkets.user_specific_limits (
    binary_user_id, market_type, client_type
)
VALUES (1, 'financial', 'old')
     , (1, 'gambling', 'old')
     , (1, 'financial', 'new')
     , (1, 'gambling', 'new')
     , (2, 'financial', 'old')
     , (2, 'gambling', 'old')
     , (3, 'financial', 'old')
;
