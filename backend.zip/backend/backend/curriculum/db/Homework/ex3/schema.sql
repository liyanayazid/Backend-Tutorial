BEGIN;
DROP SCHEMA IF EXISTS betonmarkets CASCADE;
DROP SCHEMA IF EXISTS transaction CASCADE;

CREATE SCHEMA betonmarkets;
CREATE SCHEMA transaction;

CREATE TABLE transaction.account (
    id             BIGSERIAL PRIMARY KEY,
    client_loginid TEXT NOT NULL,
    currency_code  TEXT NOT NULL,
    balance        NUMERIC NOT NULL DEFAULT 0,
    is_default     BOOLEAN NOT NULL DEFAULT true,
    binary_user_id BIGINT
);

CREATE TABLE betonmarkets.user_specific_limits (
    binary_user_id BIGINT,
    realized_loss  NUMERIC,
    potential_loss NUMERIC,
    market_type    TEXT NOT NULL,
    client_type    TEXT NOT NULL,
    expiry         TIMESTAMP,
    id             BIGSERIAL PRIMARY KEY,
    UNIQUE (binary_user_id, market_type, client_type)
);

CREATE UNIQUE INDEX
    ON betonmarkets.user_specific_limits(market_type, client_type)
 WHERE binary_user_id IS NULL;

\ir data.sql

COMMIT;
