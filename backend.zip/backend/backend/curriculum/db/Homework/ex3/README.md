# Description

In `query.sql` you find a `DELETE` statement which gets 3 parameters:

- `p_client_loginid`
- `p_market_type`
- `p_client_type`

It does not matter what these parameters mean. The important thing,
however, is this.

The 2 tables are logically linked by the `binary_user_id` field. The
`client_loginid` column only exists in the `transaction.account`
table.

We want to delete all rows from the
`betonmarkets.user_specific_limits` table that match the `market_type`
and `client_type` condition and belong to the same `binary_user_id` as
any row in the `account` table matching `p_client_loginid`.

A very similar thing has come up in our production environment. The
code path involved is rarely used.

# Questions

1. Does the query meet these reqiurements?
1. If not, what is missing?
1. If not, how can the query be fixed without changing its structure
1. Think about the problem without focusing on this particular
   statement. How would you implement a solution from scratch?
1. How would you prevent this problem from reoccuring in the future?

# Setup to play with the query

1. set environment variables according to your setup
   ```bash
   # these are example values
   export PGPORT=5434
   export PGDATABASE=besquare
   ```
1. setup the schema and import the data
   ```bash
   sudo -u postgres psql -f curriculum/db/SQL-basics-homework/schema.sql
   ```
1. now you can run the query like
   ```bash
   curriculum/db/SQL-basics-homework/query.sh
   ```
  
Feel free to modify everything. You can always go back to step 2. It
uses `DROP SCHEMA IF EXISTS CASCADE` to create a clean state.
