

DELETE FROM betonmarkets.user_specific_limits AS u
 USING transaction.account AS ta
 WHERE ta.client_loginid=:'p_client_loginid'
   AND ta.is_default
   AND u.market_type=:'p_market_type'
   AND u.client_type=:'p_client_type'
RETURNING u.binary_user_id
        , u.realized_loss
        , u.potential_loss
        , u.market_type
        , u.client_type
        , u.expiry
        , u.id;
