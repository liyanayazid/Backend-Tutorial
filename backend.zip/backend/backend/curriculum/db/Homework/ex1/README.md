# Ex1

Based on the tables and values in SQL-Basic (Students and universities) write the query for this question:

```
For each university, rank the students by score, highest scores first. Then build batches of 5 students. Find the average score of the 2nd batch per uni.
```

# rank students by score, highest first

select u.id, u.name, avg(score) as avg_Score from deriv.university as u join lateral ( select s.score from deriv.student as s where s.uni_id = u.id order by s.score desc offset 5 limit 5 ) as top on true group by u.id order by avg_score desc nulls last;

 id | name |      avg_score      
----+------+---------------------
  6 | UPM  | 77.0000000000000000
  5 | UKM  | 74.6000000000000000
  7 | USM  | 73.4000000000000000
  2 | MMU  | 69.4000000000000000
  8 | UTM  | 59.6000000000000000
(5 rows)


# build batches of 5 students

select \* from deriv.student where uni_id = 6 order by score desc offset 5 limit 5;

 id  | score | uni_id 
-----+-------+--------
 280 |    78 |      6
 345 |    77 |      6
 136 |    77 |      6
 115 |    77 |      6
 107 |    76 |      6
(5 rows)

# find average score of the 2nd batch per uni

select a.uni_id, avg(score) from (select \* from deriv.student where uni_id =8 order by score desc offset 5 limit 5) as a group by a.uni_id;

 uni_id |         avg         
--------+---------------------
      8 | 59.6000000000000000
(1 row)
