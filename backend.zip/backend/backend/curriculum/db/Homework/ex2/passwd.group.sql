CREATE TABLE passwd.group (
    gname      TEXT PRIMARY KEY,
    pw         TEXT,
    gid        INTEGER NOT NULL UNIQUE
);
