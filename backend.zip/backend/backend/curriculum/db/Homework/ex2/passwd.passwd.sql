CREATE DOMAIN passwd.shell AS TEXT
CHECK (VALUE =any ('{/bin/bash,/bin/false,/bin/sync,/usr/sbin/nologin}'::TEXT[]));

CREATE TABLE passwd.passwd (
    uname      TEXT PRIMARY KEY,
    pw         TEXT,
    uid        INTEGER NOT NULL UNIQUE,
    gid        INTEGER NOT NULL REFERENCES passwd.group(gid),
    comment    TEXT,
    home_dir   TEXT NOT NULL CHECK (home_dir ~ '^/'),
    shell      passwd.shell
);
CREATE INDEX ON passwd.passwd(gid); -- to support the FK
