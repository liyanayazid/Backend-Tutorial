CREATE TABLE passwd.aux_group (
    gname      TEXT NOT NULL REFERENCES passwd.group(gname),
    uname      TEXT NOT NULL REFERENCES passwd.passwd(uname),
    PRIMARY KEY (gname, uname)
);
