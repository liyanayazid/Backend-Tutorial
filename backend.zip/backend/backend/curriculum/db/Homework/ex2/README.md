# Objective

- create a postgres database cluster
- create a database
- create a schema
- setup the tables to import `/etc/group` and `/etc/passwd`
- import the tables
- run a few queries

# Creating a database cluster

- open a bash shell

- become the `postgres` user

  ```bash
  sudo -iu postgres
  ```

- create a database cluster named `besquare`

  ```bash
  pg_createcluster 13 besquare
  ```

- start the database

  ```bash
  pg_ctlcluster 13 besquare start
  ```

- find out the database port and status

  ```bash
  pg_lsclusters
  ```

  the output will be a table like this:

  ```
  Ver Cluster    Port Status Owner     Data directory                              Log file
  13  besquare  5444 online postgres  /var/lib/postgresql/13/besquare            /var/log/postgresql/postgresql-13-besquare.log
  ```

  the 3rd column is the port number. (5444 in the listing above)

- connect to the database using the `psql` shell. Pass the port number using the `-p` command line switch.

  ```bash
  psql -p 5444
  ```

  This will be our tool to explore postgres. So, take a few minutes to familiarize yourself. If you type `\?` followed by the `ENTER` key you get a list of the available commands implemented by the shell. `\h` gives you some help about SQL commands. Other interesting command for now are `\q` and `\i`. Check out what they do.

# Creating a database

- in the `psql` shell

  ```sql
  CREATE DATABASE besquare;
  ```

- now leave the `psql` shell and return to bash

- then connect to the newly created database

  ```bash
  psql -p 5444 besquare
  ```

  The difference to the command before is the extra parameter which tells which database in the cluster to connect to.

# Creating the schema

You need to create the `passwd` schema manually. Refer to the slides.

For each of the tables in our data model, you can find a separate file in this directory:

- `passwd.group.sql`
- `passwd.passwd.sql`
- `passwd.aux_group.sql`

You will also find a file called `fill-it-up.sql` which copies the content of your `/etc/passwd` and `/etc/group` to those database tables.

# Questions

Try to answer these questions. If you need help, ask! Nobody is perfect. Don't be shy to ask! At Deriv you will not be judged for asking stupid questions. Banging your head against a problem for 3 days without any progress, however, is bad. So, get into the habit to ask.

- what is the home directory of the `man` user?

# Ans
select home_dir from passwd.passwd where uname ='man';

= /var/cache/man   

- what is the lowest id of a group where the `admin` user is a member of?
# Ans
select * from passwd.group as g join passwd.aux_group as a on g.gname = a.gname where uname= 'liyana' order by g.gid asc limit 1;

gname | pw | gid | gname | uname  
-------+----+-----+-------+--------
 adm   | x  |   4 | adm   | liyana



- how many groups have the `admin`  user as member?

# Ans
select count(*) from passwd.aux_group where uname = 'liyana';

count 
-------
     8
(1 row)



- which shells are used by less than 5 users?

# Ans

select shell, count(*) from passwd.passwd group by shell having count(*) < 5;

   shell   | count 
-----------+-------
 /bin/bash |     3
 /bin/sync |     1
