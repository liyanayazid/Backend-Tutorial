\copy passwd.group from program 'sed </etc/group "s/:[^:]*$//" | tr : \\t'
\copy passwd.passwd from program 'tr </etc/passwd : \\t'
\copy passwd.aux_group from program 'perl -anlF: -e ''if ($F[3]) { print "$F[0]\t$_" for (split /,/, $F[3]) }'' </etc/group'
