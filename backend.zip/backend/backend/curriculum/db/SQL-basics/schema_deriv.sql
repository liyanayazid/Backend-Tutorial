DROP SCHEMA IF EXISTS deriv CASCADE;

CREATE SCHEMA deriv;

CREATE TABLE deriv.person (
    id BIGSERIAL PRIMARY KEY,
    firstname TEXT NOT NULL,
    lastname TEXT NOT NULL,
    phone TEXT
);

CREATE TABLE deriv.university (
    id BIGSERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    contact BIGINT REFERENCES deriv.person(id)
);

CREATE TABLE deriv.student (
    id BIGSERIAL PRIMARY KEY
                 REFERENCES deriv.person(id),
    score SMALLINT
          CHECK (0 <= score AND score <= 100),
    uni_id BIGINT REFERENCES deriv.university(id)
);
