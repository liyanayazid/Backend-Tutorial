BEGIN;
\ir schema_j.sql
\ir data_j.sql
\ir schema_n.sql
\ir data_n.sql
\ir schema_deriv.sql
\ir data_deriv.sql
COMMIT;
