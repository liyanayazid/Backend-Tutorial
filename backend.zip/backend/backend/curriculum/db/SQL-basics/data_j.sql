COPY j.t1 (c1, c2) FROM stdin;
a	z
b	y
c	x
\.
COPY j.t2 (f1, f2) FROM stdin;
A	Z
B	Y
D	W
\.
