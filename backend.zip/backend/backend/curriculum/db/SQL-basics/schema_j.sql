DROP SCHEMA IF EXISTS j CASCADE;

CREATE SCHEMA j;

CREATE TABLE j.empty (
    f1 text,
    f2 text
);

CREATE TABLE j.t1 (
    c1 text,
    c2 text
);

CREATE TABLE j.t2 (
    f1 text,
    f2 text
);

