COPY n.chk (i, j) FROM stdin;
1	4
2	3
\N	4
200	\N
\N	\N
\.
COPY n.null_fun (c1, c2) FROM stdin;
\N	\N
1	-1
\N	-2
2	\N
12	\N
\.
