COPY deriv.person (id, firstname, lastname, phone) FROM stdin;
2	Mahrous	Amer	\N
3	Arash	Taher	\N
4	Azlina	Ahmad	\N
105	Delta	Zip	\N
106	Pixel	Ranger	\N
107	Quill	Miracle	\N
108	Sterling	Teddy	\N
109	Mica	Harbor	\N
110	Maverick	Worth	\N
111	Rogue	Victor	\N
112	Holly	Treasure	\N
113	Sailor	Piper	\N
114	Rue	Pansy	\N
115	Lynx	Beacon	\N
116	Leaf	Melody	\N
117	Sincere	Shadow	\N
118	Lane	Lyric	\N
119	Phoenix	Winter	\N
120	Ivory	Jetty	\N
121	January	Maverick	\N
122	Serenity	Moxie	\N
123	Marsh	Cobalt	\N
124	Onyx	Joy	\N
125	Major	Lotus	\N
126	Fisher	Drake	\N
127	Rosemary	River	\N
128	Harmony	Angel	\N
129	Ginger	Plum	\N
130	Queen	Marsh	\N
131	Rose	Duke	\N
132	Canon	Saffron	\N
133	Rain	Mauve	\N
134	Stylus	Sapphire	\N
135	Ivy	Peony	\N
136	Angel	Read	\N
137	Kale	Ridge	\N
138	Shell	Birdie	\N
139	Misty	Arbor	\N
140	Liberty	Meadow	\N
141	Duke	Canon	\N
142	Colt	Cantor	\N
143	Reef	Tau	\N
144	Cadence	Teal	\N
145	Psalm	Timber	\N
146	Ruby	Daisy	\N
147	Peace	Holly	\N
148	Parson	Crystal	\N
149	Ray	Coral	\N
150	Ledger	Shell	\N
151	Treasure	Justice	\N
152	Eloquence	Scarlet	\N
153	Saint	Magenta	\N
154	Riot	Ginger	\N
155	Valley	Summer	\N
156	Calyx	Shepherd	\N
157	Shore	Cherish	\N
158	Teddy	Grace	\N
159	Destiny	Snow	\N
160	Haven	Psalm	\N
161	River	Valley	\N
162	Journey	Ocean	\N
163	Aster	Pharaoh	\N
164	Copper	Verity	\N
165	Miracle	Calliope	\N
166	Orchid	Dove	\N
167	Felicity	Blade	\N
168	Marshall	Noon	\N
169	Cinder	Emerald	\N
170	Snow	Otter	\N
171	Prince	Andromeda	\N
172	Aquamarine	Merry	\N
173	Candy	Heath	\N
174	Breeze	Ray	\N
175	Pepper	Hunter	\N
176	Lake	Puma	\N
177	Skipper	Lark	\N
178	Valor	Starling	\N
179	Legacy	Ivory	\N
180	Wade	Zinnia	\N
181	Fable	Journey	\N
182	Bishop	Love	\N
183	Crystal	Sincere	\N
184	Legend	Promise	\N
185	Violet	Case	\N
186	Blessing	Lake	\N
187	Andromeda	Breeze	\N
188	Suede	Gray	\N
189	Navy	Nova	\N
190	Arrow	Story	\N
191	Otter	Blue	\N
192	Lily	Fox	\N
193	Dew	Atlas	\N
194	Grant	Fuchsia	\N
195	Fuchsia	Trinity	\N
196	Hunter	Banner	\N
197	Timber	Messiah	\N
198	Park	Sorrel	\N
199	Genesis	Solo	\N
200	Prairie	Trace	\N
201	Scarlet	Ford	\N
202	Holiday	Poppy	\N
203	Autumn	Sandy	\N
204	Trinity	Destiny	\N
205	Porter	Gene	\N
206	Maple	Prince	\N
207	Poppy	Tulip	\N
208	Marigold	Briar	\N
209	Marvel	Fawn	\N
210	Alto	Java	\N
211	Sage	Poet	\N
212	Gentry	Brie	\N
213	Jade	America	\N
214	Mercury	Topaz	\N
215	Hawk	Deuce	\N
216	Buddy	Logic	\N
217	Lark	Marvel	\N
218	Cedar	Talon	\N
219	Rhythm	Spring	\N
220	Silver	Blessing	\N
221	Cove	Fjord	\N
222	Juniper	Chord	\N
223	Paisley	Jewel	\N
224	Poet	North	\N
225	Heather	Lumen	\N
226	Dove	Adagio	\N
227	Amber	Bunny	\N
228	Wren	Ivy	\N
229	Aquaria	Peridot	\N
230	Sunday	Maple	\N
231	Jubilee	Monday	\N
232	True	Reef	\N
233	Rocky	Garnet	\N
234	Tag	Heather	\N
235	Laurel	Alto	\N
236	Love	Seven	\N
237	Arbor	Bliss	\N
238	Camellia	Sky	\N
239	Cannon	Arrow	\N
240	Apple	Theory	\N
241	Zinnia	Hazel	\N
242	Topaz	Ledger	\N
243	Saga	Peace	\N
244	Banner	Genesis	\N
245	Olive	Turquoise	\N
246	Sorrel	Earl	\N
247	Lyric	Navy	\N
248	Cascade	Flora	\N
249	Clover	Park	\N
250	Cash	Clay	\N
251	Petal	Rain	\N
252	Bunny	Aurora	\N
253	Saffron	Pearl	\N
254	Princess	Prairie	\N
255	Zip	Rogue	\N
256	Herb	Chastity	\N
257	Buck	Lynx	\N
258	Jetty	Shore	\N
259	Briar	Pepper	\N
260	Cobalt	Laurel	\N
261	Deacon	Dash	\N
262	Patience	Gates	\N
263	Noon	Penny	\N
264	Gray	Ransom	\N
265	Faith	Hope	\N
266	Steel	Rebel	\N
267	Star	Banks	\N
268	Archer	Autumn	\N
269	Posy	Chip	\N
270	Chord	Sunday	\N
271	Opal	Cache	\N
272	Sparrow	Harmony	\N
273	Banks	Primrose	\N
274	Worth	Posy	\N
275	Aqua	Blaze	\N
276	Honey	Princess	\N
277	Solo	Archer	\N
278	Garnet	Buddy	\N
279	Penny	Juniper	\N
280	Daisy	Wade	\N
281	Tansy	Titan	\N
282	Ace	Amethyst	\N
283	Jazz	Lily	\N
284	Pearl	Haven	\N
285	Turquoise	Chance	\N
286	Merry	King	\N
287	Merit	Cascade	\N
288	Mason	Meridian	\N
289	Primrose	Lane	\N
290	Tulip	Solstice	\N
291	Crew	Steel	\N
292	Mercy	Van	\N
293	Rainbow	Bay	\N
294	Rally	Dew	\N
295	Royal	Fable	\N
296	Earl	Rhythm	\N
297	Diamond	Eloquence	\N
298	Alpha	Camellia	\N
299	Case	Cliff	\N
300	Ransom	Stylus	\N
301	Wolf	Indigo	\N
302	Peach	Olive	\N
303	Grace	Sailor	\N
304	Nova	Rose	\N
305	Trace	Angel	\N
306	Summer	Bear	\N
307	Winter	Dream	\N
308	Royalty	Merit	\N
309	Cherish	Colt	\N
310	Cookie	Hawk	\N
311	Gage	Tiger	\N
312	Icy	Legend	\N
313	Blue	Rosemary	\N
314	Taffy	Jubilee	\N
315	Peregrine	Honor	\N
316	Clay	Peach	\N
317	Cantor	Stone	\N
318	Revel	Reed	\N
319	Teal	Queen	\N
320	Ranger	Majesty	\N
321	Peridot	Aquamarine	\N
322	Rocket	Charity	\N
323	Ambrosia	Rocky	\N
324	Beacon	Paisley	\N
325	Indigo	Fisher	\N
326	Anemone	Felicity	\N
327	Savvy	Savvy	\N
328	Drake	Major	\N
329	Meridian	Taffy	\N
330	Moss	Pike	\N
331	Brie	Faith	\N
332	Scout	Candy	\N
333	Honesty	Porter	\N
334	Dream	Charisma	\N
335	Kit	Rue	\N
336	Sandy	Patience	\N
337	Promise	Parson	\N
338	Moxie	Phoenix	\N
339	Ember	Glen	\N
340	Falcon	Opal	\N
341	Dusty	Aquaria	\N
342	Charity	Legacy	\N
343	Fawn	Ember	\N
344	Spring	Anemone	\N
345	Chip	Bishop	\N
346	Ridge	Lavender	\N
347	Pharaoh	Reign	\N
348	Hope	Achara	\N
349	Raven	Revel	\N
350	Creed	Carter	\N
351	Blaze	Cannon	\N
352	Emerald	Apple	\N
353	Read	Suede	\N
354	Shepherd	Coyote	\N
355	America	Aprille	\N
356	Magnolia	Stark	\N
357	Bay	Alpha	\N
358	Cache	Creed	\N
359	Logic	Petal	\N
360	Shadow	Moss	\N
361	Story	Aqua	\N
362	Majesty	Cinder	\N
363	Tau	Dusty	\N
364	Jewel	Icy	\N
365	Titan	Ruby	\N
366	Solstice	Cookie	\N
367	Melody	Cash	\N
368	Ocean	Orchid	\N
369	Mauve	Herb	\N
370	Stark	Kale	\N
371	Victor	Misty	\N
372	Robin	Symphony	\N
373	Saber	Baker	\N
374	Adagio	Quill	\N
375	Aprille	Lilac	\N
376	King	Clover	\N
377	Carter	Sterling	\N
378	Magenta	Diamond	\N
379	Birdie	Flint	\N
380	Sky	Holiday	\N
381	Starling	Wednesday	\N
382	Reign	Frost	\N
383	Harbor	Silver	\N
384	Messiah	True	\N
385	Reed	Calyx	\N
386	Dash	Tansy	\N
387	North	Honesty	\N
388	Puma	Magnolia	\N
389	Honor	Jazz	\N
390	Charisma	Dell	\N
391	Blade	Copper	\N
392	Plum	Glory	\N
393	Fjord	Liberty	\N
394	Deuce	Beta	\N
395	Seven	Mica	\N
396	Joy	Leaf	\N
397	Sable	Mason	\N
398	Meadow	Willow	\N
399	Flint	Royal	\N
400	Angel	Marigold	\N
401	Heaven	Crew	\N
402	Verity	Sparrow	\N
403	Gene	Ace	\N
404	Chastity	Deacon	\N
405	Ash	Sage	\N
406	Ford	Rocket	\N
407	Atlas	Jack	\N
408	Coyote	Jade	\N
409	Bliss	Serenity	\N
410	Justice	Aster	\N
411	Bear	Sunny	\N
412	Lavender	Scout	\N
413	Sapphire	Buck	\N
414	Java	Mercy	\N
415	Talon	Ash	\N
416	Tiger	Wren	\N
417	Hazel	Saga	\N
418	Peony	Cove	\N
419	Lilac	Falcon	\N
420	Dell	Rainbow	\N
421	Mention	Riot	\N
422	Frost	Royalty	\N
423	Achara	Saber	\N
424	Stone	Peregrine	\N
425	Cliff	Onyx	\N
426	Fox	Skipper	\N
427	Glory	Mercury	\N
428	Lotus	Robin	\N
429	Gates	Mention	\N
430	Willow	Wolf	\N
431	Calliope	Heaven	\N
432	Lumen	Cedar	\N
433	Piper	Valor	\N
434	Van	Ambrosia	\N
435	Theory	Star	\N
436	Jack	Amber	\N
437	Pike	Cadence	\N
438	Flora	Gentry	\N
439	Coral	January	\N
440	Baker	Marshall	\N
441	Sunny	Honey	\N
442	Aurora	Tag	\N
443	Beta	Grant	\N
444	Glen	Sable	\N
445	Heath	Kit	\N
446	Rebel	Raven	\N
447	Symphony	Pixel	\N
448	Wednesday	Delta	\N
449	Monday	Violet	\N
450	Amethyst	Rally	\N
451	Chance	Saint	\N
452	Pansy	Gage	\N
\.
COPY deriv.university (id, name, contact) FROM stdin;
2	MMU	4
3	Limkokwing	4
4	UM	\N
5	UKM	\N
7	USM	\N
8	UTM	\N
9	UM	\N
6	UPM	\N
\.
COPY deriv.student (id, score, uni_id) FROM stdin;
127	71	7
128	65	5
129	62	6
130	56	6
131	51	5
132	53	8
133	57	7
134	45	6
135	47	6
136	77	6
137	50	7
138	67	7
139	63	5
140	61	5
141	64	7
142	48	2
143	58	5
144	55	7
145	57	7
146	60	6
147	93	7
148	51	8
149	53	7
150	62	7
151	39	2
152	66	6
153	60	5
154	65	5
155	57	5
156	63	6
157	70	7
158	45	5
159	45	5
160	51	7
161	49	6
162	41	6
163	72	6
164	49	5
165	58	5
166	80	7
167	49	6
168	54	6
169	52	6
170	64	6
171	49	6
172	54	7
173	43	6
174	59	6
175	40	2
176	70	6
177	64	2
178	63	7
179	52	7
180	60	7
181	55	5
182	45	7
183	72	7
184	70	7
185	70	7
186	61	7
187	82	5
188	77	5
189	60	6
190	56	6
191	81	5
192	72	6
193	49	5
194	70	7
195	63	8
240	58	6
241	47	8
242	63	5
243	64	6
244	78	\N
245	70	2
246	46	5
247	57	6
248	42	6
249	31	6
250	68	2
251	61	6
252	78	2
253	44	7
254	72	7
255	73	5
256	74	7
257	52	2
258	30	6
259	54	5
260	61	5
261	63	6
262	79	5
263	46	2
264	59	6
265	63	6
266	61	6
267	77	5
268	54	7
269	56	6
270	63	7
271	53	2
272	46	7
273	56	6
274	74	5
275	48	7
276	64	6
277	56	2
278	68	5
279	69	6
280	78	6
281	52	7
282	46	6
283	57	5
284	43	5
285	84	7
286	64	2
298	56	\N
287	60	5
288	52	2
289	60	7
290	54	7
291	50	7
292	58	6
293	63	6
294	59	6
295	65	2
296	51	2
297	50	8
299	46	6
312	62	6
313	57	6
314	49	7
315	49	8
316	58	5
317	71	5
318	58	8
319	67	6
320	51	8
321	68	7
322	73	2
323	39	5
324	42	6
325	35	6
326	37	5
327	64	7
328	49	6
329	54	7
330	70	7
331	48	7
332	73	2
333	64	5
334	65	2
335	60	5
336	60	7
337	58	6
338	51	5
339	58	6
340	59	2
341	80	7
342	45	6
393	51	5
394	49	5
395	55	6
396	61	6
397	58	6
398	38	8
399	59	6
400	54	6
401	71	2
402	60	5
403	53	7
404	47	5
405	55	5
446	54	5
447	59	6
448	58	5
449	69	7
450	61	5
451	68	6
452	43	5
406	89	\N
105	46	6
106	58	7
107	76	6
108	64	6
109	59	7
110	53	5
111	76	7
112	63	6
113	34	7
114	43	6
115	77	6
116	55	6
117	52	5
118	73	6
119	50	6
120	41	5
121	52	5
122	42	6
123	36	7
124	62	5
125	27	6
126	69	7
300	37	5
301	61	2
302	59	8
303	53	7
304	57	5
305	64	7
306	78	8
307	44	7
308	63	6
309	61	5
310	57	2
311	63	5
356	40	6
357	77	7
358	47	7
359	56	6
360	63	5
361	58	7
362	74	6
363	53	6
364	68	8
365	70	6
366	54	5
367	63	2
368	72	6
369	57	7
370	69	8
371	53	6
372	69	7
373	49	6
374	61	5
375	53	6
376	62	6
377	48	5
378	90	6
379	72	7
380	49	8
381	74	6
382	70	8
383	61	6
384	66	5
385	69	6
386	76	5
387	60	6
388	43	2
389	63	6
390	48	6
391	47	7
392	52	5
407	56	7
408	48	7
409	61	7
410	56	7
411	72	7
412	39	7
413	70	6
414	45	6
415	82	6
416	70	7
417	64	6
418	49	7
419	54	5
420	40	8
421	58	6
422	54	7
423	65	7
424	60	6
425	68	5
426	69	6
427	65	8
428	35	7
429	58	5
430	45	6
431	57	6
432	43	7
433	53	7
434	52	5
435	61	5
436	64	5
437	60	2
438	56	6
439	64	7
440	66	6
441	57	6
442	54	7
443	53	7
444	76	6
445	52	7
196	64	5
197	80	6
198	52	2
199	55	7
200	68	6
201	81	2
202	58	6
203	58	6
204	55	6
205	58	6
206	59	5
207	62	6
208	58	6
209	71	8
210	69	5
211	36	7
212	58	7
213	55	7
214	74	6
215	60	2
216	53	8
217	53	6
218	78	6
219	67	4
220	52	6
221	87	6
222	56	7
223	62	6
224	68	5
225	45	6
226	44	6
227	51	8
228	79	5
229	30	7
230	54	7
231	70	7
232	78	2
233	66	\N
234	62	7
235	56	7
236	78	2
237	69	5
238	74	6
239	59	6
343	59	\N
344	66	7
345	77	6
346	60	6
347	73	5
348	56	5
349	55	6
350	54	6
351	73	7
352	57	6
353	61	6
354	45	6
355	58	7
\.
SELECT pg_catalog.setval('deriv.person_id_seq', 452, true);
SELECT pg_catalog.setval('deriv.university_id_seq', 9, true);
