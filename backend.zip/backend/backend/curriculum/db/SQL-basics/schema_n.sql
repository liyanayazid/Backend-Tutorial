DROP SCHEMA IF EXISTS n CASCADE;

CREATE SCHEMA n;

CREATE TABLE n.chk (
    i integer,
    j integer,
    CONSTRAINT chk_check CHECK (((i + j) = 5))
);

CREATE TABLE n.null_fun (
    c1 numeric,
    c2 double precision
);
