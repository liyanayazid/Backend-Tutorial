# Adapter

### Problem

Consider an online shopping cart in which a shipping object is used to compute shipping costs. The old Shipping object is replaced by a new and improved Shipping object that is more secure and offers better prices.

The new object is named `AdvancedShipping` and has a very different interface which the client program does not expect. One solution is to change the client code to start using `AdvancedShipping` interface. If you have multiple clients, then the problem is updating each client module (not feasible in real world).

### Solution

An adapter object, `ShippingAdapter`, allows the client program to continue functioning without any API changes by mapping (adapting) the old Shipping interface to the new `AdvancedShipping` interface.        

```javascript
// shipping.js
class Shipping {
    request(zipStart, zipEnd, weight) {
        this.zipStart = zipStart;
        this.zipEnd = zipEnd;
        this.weight = weight;
        
        return "$49.75";
    }
}

module.exports = Shipping;
```

Now, imagine you would have a new requirement to add new features.

```javascript
// advance_shipping.js
class AdvanceShipping {
    login(credentials) { /* ... */ };
    setStart(start) { /* ... */ };
    setDestination(destination) { /* ... */ };
    calculate(weight) { return "$39.50"; };
}

module.exports = AdvanceShipping;
```

So instead of changing the client code, we can write a adapter to connect the old call to the new interface without changing the API

```javascript
// shipping_adapter.js
const AdvancedShipping = require('./advance_shipping');

class ShippingAdapter {
    constructor() {
        this.shipping = new AdvancedShipping();
    }
    
    request(zipStart, zipEnd, weight) {
        this.shipping.setStart(zipStart);
        this.shipping.setDestination(zipEnd);
        return this.shipping.calculate(weight);
    }
}

module.exports = ShippingAdapter;
```

Now the client can make the same call, `request` against the adapter.

```javascript
// index.js
const Shipping = require('./shipping');
const ShippingAdapter = require('./shipping_adapter');

var shipping = new Shipping();
var adapter = new ShippingAdapter();

// original shipping object and interface
var cost = shipping.request("78701", "10010", "2 lbs");
console.log("Old cost: " + cost);

// new shipping object with adapted interface
cost = adapter.request("78701", "10010", "2 lbs");

console.log("New cost: " + cost);
```

### Reference

https://refactoring.guru/design-patterns/adapter
