# Singleton

### Problem

Imagine you need to develop a bank class that can have fund deposited from account or through ATM.

How would you:

- ensure that a class has just a single instance?
- provide a global access point to that instance?

```javascript
class Bank {
    constructor() {
        this.cash = 0
    }

    deposit(amount) {
        this.cash += amount;
        return this.cash;
    }

    withdraw(amount) {
        if (amount <= this.cash) {
            this.cash -= amount;
            return true;
        } else {
            return false;
        }
    }

    total() {
        return this.cash;
    }
}

module.exports = Bank;
```

```javascript
const Bank = require('./bank');

const fund = new Bank(); // a separate instance
const atm = new Bank(); // a separate instance

fund.deposit(10000);
atm.deposit(20);

console.log(`total-atm: ${atm.total()}`)
fund.deposit(2000);
console.log(`total-fund after depositing 2000: ${fund.total()}`);
```

```shell
total-atm: 20
total-fund after depositing 2000: 12000
```

### Solution

All implementations of the Singleton have these two steps in common:

- Make the default constructor private, to prevent other objects from using the new operator with the Singleton class.
- Create a static creation method that acts as a constructor. Under the hood, this method calls the private constructor to create an object and saves it in a static field. All following calls to this method return the cached object.

If your code has access to the Singleton class, then it’s able to call the Singleton’s static method. So whenever that method is called, the same object is always returned.

```javascript
class Bank {
    constructor() {
        this.cash = 0
    }

    deposit(amount) {
        this.cash += amount;
        return this.cash;
    }

    withdraw(amount) {
        if (amount <= this.cash) {
            this.cash -= amount;
            return true;
        } else {
            return false;
        }
    }

    total() {
        return this.cash;
    }
}

module.exports = new Bank(); // modified to return a instance
```

```javascript
const fund = require('./bank'); // bank instance
const atm1 = require('./bank'); // refer to same bank instance
const atm2 = require('./bank'); // refer to same bank instance

fund.deposit(10000)

atm1.deposit(20)
atm2.withdraw(120)

console.log(`total-atm1: ${atm1.total()}`)
console.log(`total-atm2: ${atm2.total()}`)

fund.deposit(2000)
console.log(`total-fund after depositing 2000: ${fund.total()}`)
```

```shell
total-atm1: 9900
total-atm2: 9900
total-fund after depositing 2000: 11900
```

### Reference

https://refactoring.guru/design-patterns/singleton