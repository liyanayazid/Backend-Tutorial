# Strategy

### Problem

Let's say you're making a game and you have a Character class. This game has all sorts of different terrain types so your character can run through open fields, walk slowly through swamps or swim under the ocean. Since you don't know what kind of other terrains the game designer is going to think up you decide that it would be a bad idea to give each character run, walk, and swim methods. After all, what if suddenly the character needs to fly or crawl? What if they're wounded and they need to limp? 

There's a good chance you would write a code like:

```javascript
function move() {
	if (state === 'walking') {
		// do some walk
	} else if (state === 'running') {
		// do some running
	} else if (state === 'limping') {
		// do some limping
	}
}
```

### Solution

What if we took the code that made her run and we put it in its own  object? How about we just define a Class for movements and we do this  for all the different kinds of motion? Then when we need to move our  Character we'll just tell it to defer to one of these Movement objects.

**We need a Strategy to deal with this**

How about we just define a Class for movement?

```javascript
// movement.js
class Movement {
    constructor(movement) {
        this.move = movement
    }

    execute = function () {
        this.move();
    }

    changeMovementType(movement) {
        this.movement = movement;
    }
}

module.exports = Movement;
```

Now, let's define all the movements we currently have

```javascript
// strategy.js
const Movement = require("./movements");

module.exports = {
    Running: new Movement(function () {
        console.log("I'm running!");
    }),
    Walking: new Movement(function () {
        console.log("I'm walking!");
    }),
    Limping: new Movement(function () {
        console.log("I'm hurt! I can only limp!");
    })
}
```

Let's define our Character

```javascript
// character.js
class Character {
    changeMovementType(movement) {
        this.movement = movement;
    }

    move() {
        this.movement.execute();
    }
}

module.exports = Character;
```

Let's bring them our hero to life and force it to change strategy based on a situation

```javascript
const strategy = require('./strategy');
const Character = require('./character');

let hero = new Character();
hero.changeMovementType(strategy.Walking);
hero.move();

console.log('OH NO DINOSAURS!!!');

hero.changeMovementType(strategy.Running);
hero.move();

console.log('OH NO DINOSAUR BITE ME!!!');

hero.changeMovementType(strategy.Limping);
hero.move();
```

Now it's easy for us to add as many different kinds of motion as our little game designer can dream up. Want to give the character gas-powered robotic legs? No problem!

Just need to add to our strategy file

```javascript
RobotLegs : new Movement(function() {
	console.log("Look out humans!");
});
```

and call this to change the type

```javascript
hero.changeMovementType(strategy.RobotLegs);
hero.move();
```

### Reference

https://refactoring.guru/design-patterns/strategy

https://robdodson.me/posts/javascript-design-patterns-strategy/