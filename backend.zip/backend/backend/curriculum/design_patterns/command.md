# Command

### Problem

Imagine you are working on a calculator app that only supports `add` and `subtract`.

```javascript
// calculator.js
class Calculator {
	constructor() {
		this.value = 0;
	}
	add(valueToAdd) {
		this.value += valueToAdd;
	}
	substract(valueToSubtract) {
		this.value -= valueToSubtract;
	}
}

module.exports = Calculator;
```

```javascript
// index.js
const Calculator = require('./calculator');

const calculator = new Calculator();
calculator.add(10);

calculator.substract(4);

console.log(calculator.value);
```

Now in this code, if we want to perform:

- undo some calculation so how to do?
- want to see history of operations
- want to perform add and subtract together with chaining?

### Solution

Good software design is often based on the *principle of separation of concerns*, which usually results in breaking an app into layers.

1. Create a class for each operation of calculator like- AddCommand, SubtractCommand

   ```javascript
   // commands.js
   class AddCommand {
       constructor(valueToAdd) {
           this.valueToAdd = valueToAdd;
       }
   
       execute(currentValue) {
           return currentValue + this.valueToAdd;
       }
   
       undo(currentValue) {
           return currentValue - this.valueToAdd;
       }
   }
   
   class SubstractCommand {
       constructor(valueToSubtract) {
           this.valueToSubtract = valueToSubtract;
       }
   
       execute(currentValue) {
           return currentValue - this.valueToSubtract;
       }
   
       undo(currentValue) {
           return currentValue + this.valueToSubtract;
       }
   }
   
   module.exports = {
       AddCommand : AddCommand,
       SubtractCommand : SubstractCommand,
   };
   ```

2. Create an interface class **Calculator** which will execute all these class as a command. The external user only call the **Calculator** class

   ```javascript
   // calculator.js
   class Calculator {
   	constructor() {
   		this.value = 0;
           this.history = [];
   	}
   	execute(command) {
           this.value = command.execute(this.value);
   		this.history.push(command);
   	}
   	undo() {
   		const command = this.history.pop();
           this.value = command.undo(this.value);
   	}
   }
   
   module.exports = Calculator;
   ```

   ```javascript
   // index.js
   const Calculator = require('./calculator');
   const Commands = require('./command.js');
   
   const calculator = new Calculator();
   calculator.execute(new Commands.AddCommand(10));
   
   calculator.execute(new Commands.SubtractCommand(4));
   
   console.log(calculator.value);
   console.log(calculator.history);
   ```




### Reference

https://refactoring.guru/design-patterns/command