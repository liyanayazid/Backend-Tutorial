# Facade

### Problem

Imagine that you must make your code work with a broad set of objects that belong to a sophisticated library or framework. Ordinarily, you’d need to initialize all of those objects, keep track of dependencies, execute methods in the correct order, and so on.

As a result, the business logic of your classes would become tightly coupled to the implementation details of 3rd-party classes, making it hard to comprehend and maintain.

**Code**

Imagine you are working on a cleaning house software. We have the following objects `Bed`, `Freshner`, and `Trash`

```javascript
// bed.js
class Bed {
    makeTheBed() {
        console.log('The bed is ready');
    }
}

module.exports = Bed;
```

```javascript
// freshner.js
class Freshner {
    spray() {
        console.log('A nice smell spreads through the air')
    }
}

module.exports = Freshner;
```

```javascript
// trash.js
class Trash {
    takeOutTrash() {
        console.log('The trash is taken out')
    }
}

module.exports = Trash;
```

We often might find ourselves wanting to execute the above methods in a  particular order. 

```javascript
// index.js
const Bed = require('./bed');
const Freshner = require('./freshner');
const Trash = require('./trash');

function cleanHouse() {
    (new Bed()).makeTheBed();
    (new Freshner()).spray();
    (new Trash()).takeOutTrash();
}

cleanHouse();
```

Doing so multiple times across our codebase would  violate the [**Don’t Repeat Yourself (DRY)**](https://en.wikipedia.org/wiki/Don't_repeat_yourself) principle. To avoid the above, we can create a **Facade** class.

```javascript
// house_cleaning_facade.js
const Bed = require('./bed');
const Freshner = require('./freshner');
const Trash = require('./trash');

class HouseCleaningFacade {
    constructor({ bed = new Bed(), trashCan = new Trash(), airFreshener = new Freshner() } = {}) {
        this.bed = bed;
        this.trashCan = trashCan;
        this.airFreshener = airFreshener;
    }

    cleanTheHouse() {
        this.bed.makeTheBed();
        this.trashCan.takeOutTrash();
        this.airFreshener.spray();
    }
}

module.exports = HouseCleaningFacade;
```

Now the index.js 

```javascript
// index.js
const HouseCleaningFacade = require('./house_cleaning_facade');

(new HouseCleaningFacade()).cleanTheHouse();
```

### Reference

https://refactoring.guru/design-patterns/facade
