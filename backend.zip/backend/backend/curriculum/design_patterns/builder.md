# Builder

### Problem

Imagine a complex object that requires laborious, step-by-step  initialization of many fields and nested objects. Such initialization  code is usually buried inside a monstrous constructor with lots of  parameters.

For example, let’s think about how to create a `House` object. To build a simple house, you need to construct four walls and a floor, install a door, fit a pair of windows, and build a roof. But what if you want a bigger, brighter house, with a backyard and other goodies (like a heating system, plumbing, and electrical wiring)?

The simplest solution is to extend the base House class and create a set of subclasses to cover all combinations of the parameters. But eventually you’ll end up with a considerable number of subclasses. 

![Lots of subclasses create another problem](../images/design_patterns/builder/problem1.png)

> You might make the program too complex by creating a subclass for every possible configuration of an object.

Or you can create a giant constructor right in the base `House` class with all possible parameters that control the house object. In most cases most of the parameters will be unused, making the **constructor calls pretty ugly**. 

![The telescopic constructor](../images/design_patterns/builder/problem2.png)

> The constructor with lots of parameters has its downside: not all the parameters are needed at all times.



### Solution

The Builder pattern suggests that you extract the object construction  code out of its own class and move it to separate objects called *builders*.

![Applying the Builder pattern](../images/design_patterns/builder/solution1.png)



**Director**  (optional)

You can go further and extract a series of calls to the builder steps  you use to construct a product into a separate class called *director*. The director class defines the order in which to execute the building  steps, while the builder provides the implementation for those steps.

Code like

```javascript
const myHouse = new House(‘John Street 14’, 4, true, true);
```

becomes

```javascript
const myHouse = new HouseBuilder(‘John Street 14’)
 .setFloor(4)
 .makeParking()
 .makeGarden()
 .build();
```

with `builder` object.

**Code sample for without builder object**

```javascript
// house.js
class House {
    constructor(address, floor, parking, garden) {
        this.address = address;
        this.floor = floor;
        this.parking = parking;
        this.garden = garden;
    }

    showInfo() {
        console.log(this);
    }
}

module.exports = House;
```

```javascript
// index.js
const House = require('./house');

const myHouse = new House('John Street 14', 4, true, true);
console.log(myHouse.showInfo());
```

**Code sample with builder object**

```javascript
// house.js
class House {
    constructor(builder) {
        this.address = builder.address;
        this.floor = builder.floor;
        this.parking = builder.parking;
        this.garden = builder.garden;
    }

    showInfo() {
        console.log(this);
    }
}

module.exports = House;
```

```javascript
// house_builder.js
const House = require('./house');

class HouseBuilder {
    constructor(address) {
        this.address = address;
    }

    setFloor(floor) {
        this.floor = floor;
        return this;
    }

    setParking(parking) {
        this.parking = parking;
        return this;
    }

    setGarden(garden) {
        this.garden = garden;
        return this;
    }

    buildInfo() {
        return new House(this);
    }
}

module.exports = HouseBuilder;
```

```javascript
// index.js
const HouseBuilder = require('./house_builder');

const houseWithParking =
    new HouseBuilder('Street 1').setFloor(2).setParking(true).setGarden(false).buildInfo();

houseWithParking.showInfo();

const houseWithGarden =
    new HouseBuilder('Street 2').setFloor(3).setParking(false).setGarden(true).buildInfo();

houseWithGarden.showInfo();
```

### Reference

https://refactoring.guru/design-patterns/builder