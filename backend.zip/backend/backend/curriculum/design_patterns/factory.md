# Factory method

### Problem

Imagine that you're creating a logistic application.

**First version**

The first version of your app can only handle transportation by trucks. 

*Code*

```javascript
// truck.js
class Truck {
    deliver() {
        return 'Deliver by land in a box.';
    }
}

module.exports = Truck
```

```javascript
// logistic.js
const Truck = require('./truck');

let truck = new Truck();

console.log(truck.deliver());
```

**Second version**

After a while, your app becomes pretty popular. Each day you receive  dozens of requests from sea transportation companies to incorporate sea  logistics into the app.

*Code*

```javascript
// ship.js
class Ship {
    deliver() {
        return 'Deliver by sea in a container.';
    }
}

module.exports = Ship
```

```javascript
// logistic.js
const Ship = require('./ship');
const Truck = require('./truck');

let truck = new Truck();
let ship = new Ship();

console.log(truck.deliver());
console.log(ship.deliver());
```

**Possible issue**

The problem will arise when the application grows and let's say some more new transport  types get added. Our *logistic.js* file will need to import all the new transport types and create instances of each.



![Adding a new transportation class to the program causes an issue](../images/design_patterns/factory/problem1.png)



> Adding a new class to the program isn’t that simple if the rest of the code is already coupled to existing classes.

### Solution

The Factory Method pattern suggests that you replace direct object construction calls (using the `new` operator) with calls to a special *factory* method. Don’t worry: the objects are still created via the `new` operator, but it’s being called from within the factory method. Objects returned by a factory method are often referred to as *products.*

You can use factories design pattern in Node.js to simply your code and  reduce messy code. You need to create a factory which will import the different transport classes. Instead of importing all transport types in *logistic.js* you can rather import the factory.

![The structure of creator classes](../images/design_patterns/factory/solution1.png)

> high level overview

![The structure of the products hierarchy](../images/design_patterns/factory/solution2.png)

> structure of product hierarchy

*Code*

```javascript
// transport.js, common interface
class Transport {
    constructor () {}

    deliver() {
        throw new Error('Not implemented');
    }
}

module.exports = Transport
```

```javascript
// truck.js
const Transport = require('./transport');

class Truck extends Transport{
    constructor () {
        super();
    }
	// override the Transport and provide it's own implementation
    deliver() {
        return 'Deliver by land in a box.';
    }
}

module.exports = Truck
```

```javascript
// ship.js
const Transport = require('./transport');

class Ship extends Transport{
    constructor () {
        super();
    }
    // override the Transport and provide it's own implementation
    deliver() {
        return 'Deliver by sea in a container.';
    }
}

module.exports = Ship
```

```javascript
// transport_factory.js
const Truck = require('./truck');
const Ship = require('./ship');

class Transport {
    create (type) {
        switch (type) {
            case 'truck': 
                return new Truck();
            case 'ship':
                return new Ship();
            default:
                throw new Error('Unsupported transport type');
        }
    }
}

module.exports = new Transport();
```

```javascript
// logistic.js
const Transport = require('./transport');

let truck = Transport.create('truck');
let ship = Transport.create('ship');

// the above truck and ship are shown for simplicity
// ideally, we would have something like this
// let modeOfTransport = Transport.create(process.env.deliverMode);
// where we pass the mode of transport at runtime to make client
// code not aware of modes we support

console.log(truck.deliver());
console.log(ship.deliver());
```

***Why don’t we create the objects using `new` keyword?***

Because we want to separate the part of code that is most likely to  change from the others. In the future, if we need to modify the process  of creating objects, we only need to change code inside the `create()` method of `SimpleFactory` class. So this client is not affected by these modifications.

### Reference

https://refactoring.guru/design-patterns/factory-method
