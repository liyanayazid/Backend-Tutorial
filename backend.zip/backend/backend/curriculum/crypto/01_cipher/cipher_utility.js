const crypto = require("crypto");

class Cipher {
  static encoding = "hex";

  constructor() {
    // Generate the private and public key here
    const { publicKey, privateKey } = crypto.generateKeyPairSync("rsa", {
      modulusLength: 2048,
    });

    //store key
    this.publicKey = publicKey;
    this.privateKey = privateKey;
  }

  rsa_encryption(plainText) {
    // Implement the RSA encryption method.
    // The expected return value is buffer or string of the cipher text.

    const encryptedData = crypto.publicEncrypt(
      this.publicKey,
      //temporary storage for string
      Buffer.from(plainText)
    );

    console.log("encrypted data: ", encryptedData.toString("base64"));
    return encryptedData.toString("base64");
  }

  rsa_decryption(cipherText) {
    // Implement the RSA decryption method.
    // The expected return value is string of the plain text.

    const decryptedData = crypto.privateDecrypt(
      this.privateKey,

      Buffer.from(cipherText, "base64")
    );

    console.log("decrypted data:", decryptedData.toString());
    return decryptedData.toString();
  }

  sha256(dataString) {
    const hash = crypto.Hash("sha256").update(dataString).digest("hex");
    return hash;

    //=========================================
    // Implement the SHA256 hash function method.
    // The expected return value is string of the cipher text hexadecimal encoded.
  }
}

module.exports = new Cipher();
