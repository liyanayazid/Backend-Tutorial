# Exercise 1

Using the **Crypto** library [(documentation)](https://nodejs.org/api/crypto.html) or any other library you choose, please implement the following:

## Asymmetric encryption/decryption
We need to implement the encryption/decryption methods in the **cipher_utility.js** file using the RSA algorithm. To do that we will first need to generate public/private keys.

## SHA256 Hash function
Implement the sha256 hash function in **cipher_utility.js** file.
