'use strict';

const CipherUtility = require('./cipher_utility');

const message = 'test message';

// RSA encryption/decryption test
const encryptedMessage = CipherUtility.rsa_encryption(message);
const decryptedMessage = CipherUtility.rsa_decryption(encryptedMessage);

if (message !== decryptedMessage) {
    throw Error('The decrypted message does not match the original message');
}

const hashMessage  = CipherUtility.sha256(message);
const expectedHash = '3f0a377ba0a4a460ecb616f6507ce0d8cfa3e704025d4fda3ed0c5ca05468728';
if (hashMessage !== expectedHash){
    throw Error('The generated hash does not match the expected hash');
}

console.log('Nice work, You have solved the exercise');


//============================
// Don't touch the above lines
//============================
