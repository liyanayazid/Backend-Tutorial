# Exercise 2

This application is a Bitcoin wallet for the testnet network.
In the **wallet.js** file, we are generating a bitcoin address using the **bitcoinjs-lib** package to receive and send bitcoins.
We store the generated addresses with the related private/public keys in **wallet_data.json** file.
The private key is a secret! We need to encrypt it before storing it and decrypt it when we need to transfer from the related address.

Using the **Crypto** library [(documentation)](https://nodejs.org/api/crypto.html) or any other library you choose, please implement the following:

## Symmetric encryption/decryption
Using the AES algorithm, we need to implement the encryption/decryption methods in **aes_cipher.js** file.

**Note:** We are reading the encyption key form the enviroment variable `AES_KEY`, so you can use the following command to run the app (replace `<YOUR_KEY>` with your key):
```
AES_KEY=<YOUR_KEY> node index.js
```
