"use strict";
const crypto = require("crypto");
//const { enc } = require('crypto-js');

const key = crypto.randomBytes(32);
const CIPHER_ALGORITHM = "aes-256-ctr";
const IV_LENGTH = crypto.randomBytes(16);
const ENCODING = "hex";

function encrypt(plainText, password) {
  //=========================================
  // Implement the AES encryption method.
  // The expected return value is
  // string of the cipher text hexadecimal encoded.
  //=========================================
  var cipher = crypto.createCipheriv("aes-256-ctr", key, IV_LENGTH);
  var encrypted = cipher.update(plainText);
  encrypted = Buffer.concat([encrypted, cipher.final()]);
  return {
    IV_LENGTH: IV_LENGTH.toString("hex"),
    encryptedData: encrypted.toString("hex"),
  };
}

function decrypt(encrypted, password) {
  //=========================================
  // Implement the AES decryption method.
  // The expected return value is
  // string of the plain text.
  //=========================================
  let IV_LENGTH = Buffer.from(encrypted.IV_LENGTH, "hex");
  let encryptedText = Buffer.from(encrypted.encryptedData, "hex");
  var decipher = crypto.createDecipheriv("aes-256-ctr", key, IV_LENGTH);
  var decrypted = decipher.update(encryptedText);
  //decrypted += decipher.final(IV_LENGTH);
  decrypted = Buffer.concat([decrypted, decipher.final()]);
  return decrypted.toString();
}

var hw = encrypt("Success");
console.log(hw);
console.log(decrypt(hw));

module.exports = {
  encrypt,
  decrypt,
};
