'use strict';

const fs      = require('fs');
const bitcoin = require('bitcoinjs-lib');
const AES     = require('./aes_cipher');

class Wallet {
    constructor(walletDataFilePath) {
        this.walletDataFilePath = walletDataFilePath;
        this.aes_key            = process.env.AES_KEY;
        this.network            = bitcoin.networks.testnet;
    }

    generate_address() {
        const keyPair       = bitcoin.ECPair.makeRandom({ network: this.network });
        const publicKey     = keyPair.publicKey;
        const privateKeyWIF = keyPair.toWIF();
        const address       = this.get_p2wpkh_address(publicKey);

        const privateKeyWIFEncrypted = AES.encrypt(privateKeyWIF, this.aes_key);

        this.save(address, { publicKey: publicKey.toString('hex'), privateKey: privateKeyWIFEncrypted });

        return address;
    }

    get_p2wpkh_address(publicKey) {
        return bitcoin.payments.p2wpkh({
            pubkey: publicKey,
            network: this.network,
          }).address;
    }

    get_address_private_key_wif(address) {
        const data                   = fs.readFileSync(this.walletDataFilePath);
        const json                   = JSON.parse(data);
        const privateKeyWIFEncrypted = json[address]['privateKey'];

        return AES.decrypt(privateKeyWIFEncrypted, this.aes_key);
    }

    validate_private_key_encryption(address) {
        const privateKeyWIF          = this.get_address_private_key_wif(address);
        const keyPair                = bitcoin.ECPair.fromWIF(privateKeyWIF, this.network);
        const publicKey              = keyPair.publicKey;
        const derivedAddress         = this.get_p2wpkh_address(publicKey);

        if(address !== derivedAddress) {
            throw Error('The decrypted private key does not match the address private key');
        }
    }

    save(address, addressDataObj) {
        try {
            const data    = fs.readFileSync(this.walletDataFilePath);
            const json    = JSON.parse(data);
            json[address] = addressDataObj;
            fs.writeFileSync(this.walletDataFilePath, JSON.stringify(json, null, 4));
        } catch (err) {
            console.error(err)
        }
    }
    build_raw_transaction(fromAddress, toAddress, amount, txID, index, input_value, txPkScripts) {
        let txBuilder = new bitcoin.Psbt({network: this.network});
        txBuilder.addInput({
            hash: txPkScripts,
            index: index,
            witnessUtxo: {
                value:10000,
                script: Buffer.from(txPkScripts, 'hex')
            }
        });

        txBuilder.addOutput({
            address: toAddress,
            value: amount
        });

        const privateKeyWIF = this.get_address_private_key_wif(fromAddress);
        const keyPair = bitcoin.ECPair.fromWIF(privateKeyWIF, this.network);

        txBuilder.signInput(0, keyPair);
        txBuilder.validateSignaturesOfAllInputs();
        txBuilder.finalizeAllInputs();
        const tx = txBuilder.extractTransaction();
        console.log(tx.toHex());
    }
}

module.exports = Wallet;
