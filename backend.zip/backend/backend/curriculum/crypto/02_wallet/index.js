'use strict';

const Wallet = require('./wallet');

const wallet  = new Wallet('wallet_data.json');
const address = wallet.generate_address();
wallet.validate_private_key_encryption(address);

console.log('Nice work, You have solved the exercise');

//============================
// Don't touch the above lines
//============================
