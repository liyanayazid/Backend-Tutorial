import { Block } from "./block.js";
export class Blockchain {
  constructor() {
    this.chain = [this.createGenesis()];
  }

  getCurrentDate() {
    //TODO get the current date
    return day + "/" + month + "/" + year;
  }

  createGenesis() {
    //starting by creating empty block
    return new Block({});
  }

  latestBlock() {
    //get the last block on the chain
    return this.chain[this.chain.length - 1];
  }

  addBlock(newBlock) {
    //check its previous hash to the correct value
    (newBlock.prevHash = this.latestBlock().hash),
      //recalculate latest hash
      (newBlock.hash = newBlock.calculateHash());
    //add block to the chain
    this.chain.push(newBlock);
  }

  checkValid() {
    // TODO check the blockchain validation
    for (let i = 0; i < this.chain.length - 1; i++) {
      const currentBlock = this.chain[i];
      const previousBlock = this.chain[i - 1];

      //The current block hash should equal to current block's hash calculation
      if (currentBlock.hash == currentBlock.calculateHash()) {
        return true;
      }
      //The current block's previous hash should equal to previous block's hash
      if (currentBlock.prevHash == previousBlock.hash) {
        return true;
      }
    }
    // If all the blocks are invalid, return false
    return false;
  }
}
