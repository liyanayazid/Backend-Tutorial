

The goal here is to create a simple blockchain with node js.&nbsp;
A blockchain is a chain of blocks linked to one another through the linked list structure. It uses the hash of the previous block to refer to it, in this exercise we want to make it simple so lets use an array to implement it.

# Step 1: Building the Block

Implement your changes on block.js 

## Assumptions:
1. Each block object takes timestamp and data as an input
2. Rather than the inputs, each block object contains index, hash of the previous block, and hash of its own 
3. Each block should be able to calculate a hash of its own. For simplicity use the block's attributes for hashing.

*tip* use `crypto-js` or `crypto` library to calculate the hash

# Step 2: Building the Blockchain

Now that we have the individual block structure created, we need to create a structure, a Blockchain class object, to link them together and to build the basic functionality that comes along with normal blockchains. 

Implement your changes on blockchain.js 

## Assumptions:
1. In blockchain convention, the very first block of any chain is also known as the “Genesis block”. For its timestamp and data fields, you can just put today’s date and “Genesis block” or anything you like. (what about the previous hash field?)

2. The chain needs the latestBlock function. This is used for getting the information about the most recent block.
3. To continuously extend our blockchain, we need an addBlock function. the requirements of this function are as follow:
	- It should take a Block object as an input and add it to the chain.
	- The new block should have its own hash.
	- This function should use the latestBlock function to give our new block a previous hash field.
	- Don't forget about each block's index!
	
4. Check the chain validation with checkValid function. For simplicity it should follow two rules:
	- The current block hash should equal to current block's hash calculation
	- The current block's previous hash should equal to previous block's hash
	
	
# Step 3: 
You can test your blockchain by running node main.js. Add as many as the block you want and check the result.