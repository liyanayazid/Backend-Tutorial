import crypto from "crypto";

export class Block {
  constructor(index, timestamp, data, prevhash = "") {
    this.timestamp = timestamp;
    this.data = data;
    this.index = index;
    this.prevhash = prevhash;
    this.hash = this.calculateHash();

    // TODO implement the attributes
  }

  calculateHash() {
    //TODO return Hash of a block
    let hashBlock =
      this.index + this.prevHash + this.timestamp + JSON.stringify(this.data);
    return crypto.createHash("sha256").update(hashBlock).digest("hex");
  }
}
