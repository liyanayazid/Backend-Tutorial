import {Blockchain} from './blockchain.js'
import {Block} from './block.js'


let chain = new Blockchain();
chain.addBlock(new Block("12/11/2021", {data: "second block", amount: 5}));
chain.addBlock(new Block("1/10/2021", {data: "third block" , amount: 10}));

console.log(JSON.stringify(chain, null, 10));
console.log("Is blockchain valid? " + chain.checkValid()); 