# TDD
A brief introduction to software testing and TDD

## Terminology

Before we getting started with the testing and TDD it's best to getting fimiliar with some related terminologies.

### Manual testing

When a human is in charge of testing the application by hand. In manual testing, a human performs the tests step by step, without test scripts.

### Automated testing
In automated testing, tests are executed automatically via test automation frameworks, along with other tools and software. In automation testing, the tool does the testing.

### Black box testing
Black Box Testing is a software testing method in which the functionalities of software applications are tested without having knowledge of internal code structure, implementation details and internal paths.

Functional testing – This black box testing type is related to the functional requirements of a system; it is done by software testers.
Non-functional testing – This type of black box testing is not related to testing of specific functionality, but non-functional requirements such as performance, scalability, usability.
Regression testing – Regression Testing is done after code fixes, upgrades or any other system maintenance to check the new code has not affected the existing code.

### White box testing
White Box Testing is software testing technique in which internal structure, design and coding of software are tested to verify flow of input-output and to improve design, usability and security. In white box testing, code is visible to testers so it is also called Clear box testing, Open box testing, Transparent box testing, Code-based testing and Glass box testing.

White box testing involves the testing of the software code for the following:

- Internal security holes
- Broken or poorly structured paths in the coding processes
- The flow of specific inputs through the code
- Expected output
- The functionality of conditional loops
- Testing of each statement, object, and function on an individual basis

### Functional testing
FUNCTIONAL TESTING is a type of software testing that validates the software system against the functional requirements/specifications. The purpose of Functional tests is to test each function of the software application, by providing appropriate input, verifying the output against the Functional requirements.

Functional testing mainly involves black box testing and it is not concerned about the source code of the application.

- Unit Testing
- Integration Testing
- White box testing
- Black Box testing
- User Acceptance testing
- Regression Testing

### Non-functional testing
Non-Functional testing checks the  Performance, reliability, scalability and other non-functional aspects of the software system.

Non-functional testing should be performed after functional testing
Performance parameters like speed, scalability are inputs to non-functional testing.
Manual Testing or automation tools can be used for functional testing

- Performance Testing
- Load Testing

### Mock
Mocking means creating a fake version of an external or internal service that can stand in for the real one, helping your tests run more quickly and more reliably.

## Testing pyramid
Testing Pyramid is a framework that can help both developers and QAs create high-quality software. It reduces the time required for developers to identify if a change they introduced breaks the code. It can also be helpful in building a more reliable test suite.

![Testing pyramid image](https://3fxtqy18kygf3on3bu39kh93-wpengine.netdna-ssl.com/wp-content/uploads/2020/01/test-automation-pyramid.jpg
    "Testing pyramid").

[Read more about testin pyramid...](https://www.browserstack.com/guide/testing-pyramid-for-test-automation)

## Definitions

### What is Unit Testing?

To understand TDD, its best to start with unit test context.
The baseline of Unit testing is that it tests every piece of code in isolation without dependencies.

A unit test exercises a **unit** of code in isolation and compares actual with expected results. For object-oriented programming, you need to consider a whole class or an interface as a unit. For procedural or functional programming it could be a single method or function. In the end, the purpose of unit testing is to validate that each unit/component of the software performs as expected.

### What is Integration Testing?
Integration testing is a level of software testing where individual units are combined and tested as a group. The purpose of this level of testing is to expose faults in the interaction between integrated units.

## Unit tests downsides

## Intergration tests downsides

## Which one do we need?

## Real-world example
Let's understand it with the example of making a breakfast, e.g.Omelet.

Here you check the quality and quantity of each ingredient to make a delicious Omelet.

- How many eggs do you have? Are they fresh?
- What kind of milk? How much? Is it spoiled?
- Is your bowl clean?
- And so on...

Here you are checking each ingredient separately without mixing them. You’re doing a unit testing in this sense. You’re testing your work and units that will comprise the product.

But note that you’re not testing the product.

Now, let's say you found eggs unhealthy. Here you know that those eggs are going to ruin your morning and hence you will replace them with fresh eggs. That's the main benefit of unit testing where you can identify the piece of code which will cause a problem in future. When you taste the omelet, you are doing Integration testing. Integration testing checks that whether all the components work together as expected.

Just bear in mind that, TDD is an approach, you can write unit or integration tests with it or even use it in your real-life like creating an omelet.

## Tests attributes

Developers need to learn how to write effective unit tests. Good unit tests attributes are:
- Fast → Run fast (they have short setups, run times, and break downs).
- Independent →tests must not depend on each other.
- Repeatable → a test must be reproducible in any environment.
- Self-Validating → a test must have a binary result (Failure or Success) for a quick and easy conclusion.
- Timely → a test must be written at the appropriate time, i.e. just before the production code it will validate.

## What is TDD?
Test driven development, is a software development paradigm that reverses the notion that you should first develop code and then test it. instead in TDD, you write your tests and then you write your code. Following are the steps of TDD:

- Write a “single” test describing an aspect of the program
- Run the test, which should fail because the program lacks that feature
- Write **just enough** code to make the test pass
- **Refactor** the code to the simplest level
- Repeat, accumulating tests over time

![TFD UML](../images/tdd/TFD.png)

In one simple sentence we can say
> Let tests lead your code

## TDD always works

## Advantages of TDD
- Find bugs at the early stage of developing
- Improves Coupling in the Software Architecture
- Gives you a clear documentation about how small pieces of the system work
- Confidence to Refactor
- Less regression testing
- More flexible in the development process

## TDD Principles
The TDD has 3 phases:

- **RED:** red stands for writing a test, this test fails becuase you havent actually written any code yet. 

- **GREEN:** in green part, you write code that passes your tests in all previous tests you have written. dont try to be clever, just write codes so your tests pass.

- **REFACTOR:** there are many reasons you might want to refactor your code such as efficiency, coding styles and readability. while you refactor, make sure your code still passes all your tests.

you repeat this cycle until your functionality is done.

![TDD principles](../images/tdd/TDD-principles.png)

<!-- ## Rules for TDD
1. you should write new code only when a test has failed. 
2. you should eliminate any duplication that you find.

how these two simple rules generate complex individual and group behavior?

- You write your own tests because you can't wait 20 times per day for someone else to write them for you.
- Your development environment must provide rapid response to small changes (e.g you need a fast compiler and regression test suite).
- Your designs must consist of highly cohesive, loosely coupled components to make testing easier. -->


## TDD Vs. Traditional Testing
TDD approach is primarily a specification technique. It ensures that your source code is thoroughly tested at confirmatory level.

- With traditional testing, a successful test finds one or more defects. It is same as TDD. When a test fails, you have made progress because you know that you need to resolve the problem.

- TDD ensures that your system actually meets requirements defined for it. It helps to build your confidence about your system.

- In TDD more focus is on production code that verifies whether testing will work properly. In traditional testing, more focus is on test case design. Whether the test will show the proper/improper execution of the application in order to fulfill requirements.

- In TDD, you achieve 100% coverage test. Every single line of code is tested, unlike traditional testing.

- The combination of both traditional testing and TDD leads to the importance of testing the system rather than perfection of the system.

## Nodejs testing tools

An underlying assumption of TDD is that you have a testing framework available to you. people will use tools such as [Mocha](https://mochajs.org/), [Jest](https://jestjs.io/) and [Jasmine](https://jasmine.github.io/) in Nodejs. You can find other tools from [here](https://developer.okta.com/blog/2020/01/27/best-nodejs-testing-tools).

## Jest

## Basic functions

## Tests structure

## Write your first test/code

## Matchers