# 1. Deploy your first Container
The first task is to identify the name of the Docker Image which is configured to run Redis. With Docker, all containers are started based on a Docker Image. These images contain everything required to launch the process; the host doesn't require any configuration or dependencies.

1. Start `Redis` container
2. Set few KVs in `Containerized Redis container`
3. Get saved keys & you set in previous step

# 2. Deploy a Static Website
Deploy Static HTML Website as Container

Use Dockerfile to Deploy a static website.
1. Create the following folders in your working directory:
    ```
    GroupX/MyName/
    └── Docker
        └── Static
            └── Dockerfile
            └── index.html
    ```
2. light weight image should be used.
3. expose 8089 port & try to access deployed website via browser.

# 3. Ignore files
Let say there is a file with some sensitive information & you are asked to prevent sensitive files or directories from being included by mistake in images.
Hint: can use any lightweight ubuntu container.

# 4. Network

Create a docker network that containers are connected to. The network has similar attributes to a physical network, allowing containers to come and go more freely than when using links.

1. Create a network.
2. Connect Redis & Ngnix container network created.
3. Both containers should be able to `ping` each other.

# 5 Data persistence
# 5.1 Keeping data safe 
Docker Volumes allows you to upgrade containers, restart machines and share data without data loss. This is essential when updating database or application versions.

1. Start a `bitnami/redis:6.0` container & add few KVs to it.
2. Upgrade it to `bitnami/redis:6.0.16` & stop it.
3. Check the KVs you added previously. Did you find them ? if no, so you lost them already.
4. Restart `bitnami/redis:6.0` container but this time mount volume while running container.
5. Add some `key/values` in it & stop it.
6. Upgrade it to `bitnami/redis:6.0.16` but keep using same volume that `bitnami/redis:6.0` was using.
7. Check the KVs you added previously. Did you find them ? if yes, then it's the `Volume` you mounted to host machine helped to persis the data.

# 5.2 Data Persisting helps in development

Recently we deployed a Static HTML website, try to make some changes in `index.html` and reload the website in browser you should be able to see new changes in the website without rebuilding the container.