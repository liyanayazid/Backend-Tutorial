# Scenario

So far you have been playing with NodeJs, Redis & Postgres separately. It's a good time to build an `Dockerized Application` with all the concepts you learnt so far. 
Ideally what application shall do is 
1. Provide an interface to interact with Application. Hint: REST API.
2. Using cURL or Postman you shall be able to


    2.1 Create/Edit Person.

    2.2 List all Persons.

    2.3 Get specific Person's details.

    2.4 Delete Person


# Requirements
1. Create the following folders in your working directory:
    ```
    GroupX/MyName/
    └── Docker
        └── nodejs-pg
            └── db_init
                └── init.sql # table creation 
            └── src
                └── server.js # entry point
                └── app.js # endpoints
                └── person.js # model
                └── package.json
            └── docker-compose.yml
            └── Dockerfile # for Nodejs container
    ```
2. Use Nodejs as backend.
3. ExpressJs for API.
4. Postgres as database & Nodejs library https://www.npmjs.com/package/pg for db interaction.
5. Use `docker-compose` to define application infrastructure.
6. Database should be initiated upon `Postgres` container build.
7. Database contains only one table:`persons` having fields `person_id (PRIMARY KEY), firstName, lastName & address`. Hint: [reference](https://github.com/besquare-deriv/backend/blob/main/curriculum/db/SQL-basics/schema_deriv.sql)
8. Data should persist even if container(s) are remove/upgraded.



